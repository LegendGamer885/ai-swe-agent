# 🚀 Detailed Guide: Pushing AI Software Engineering Agent to GitHub

This guide provides complete, step-by-step instructions to initialize, commit, and push your **AI Software Engineering Agent** codebase to a GitHub repository.

---

## 📋 Prerequisites

1. **Git installed**: (Verify by running `git --version` in terminal).
2. **GitHub Account**: If you don't have one, register at [github.com](https://github.com).
3. **GitHub Authentication**: Either:
   - **GitHub CLI (`gh auth login`)**, OR
   - **Personal Access Token (Classic)**:
     - Go to GitHub -> **Settings** -> **Developer Settings** -> **Personal Access Tokens (Tokens classic)**.
     - Click **Generate new token (classic)**.
     - Name: `ai-swe-agent-token`.
     - Check scopes: `repo` (Full control of private repositories) and `workflow`.
     - Copy and save the generated token.

---

## 🛠️ Step-by-Step Instructions

### Step 1: Open Terminal in Project Directory

Open PowerShell or Command Prompt and navigate to the project directory:

```powershell
cd C:\Users\noval\.gemini\antigravity\scratch\ai-swe-agent
```

---

### Step 2: Check Git Status & Initialize (If Needed)

Check if the repository is already initialized:

```powershell
git status
```

If it is not initialized, run:
```powershell
git init
```

---

### Step 3: Verify `.gitignore`

Ensure your `.gitignore` ignores virtual environments, caches, and secrets:

```gitignore
.venv/
venv/
__pycache__/
*.pyc
.env
.pytest_cache/
*.egg-info/
dist/
build/
```

*(Notice `.env` is ignored so your private API keys are never leaked to GitHub!)*

---

### Step 4: Stage and Commit the Files

Add all project files (core agent, FastAPI web server, modern AI UI, tests, and documentation) to Git staging:

```powershell
git add .
```

Verify staged files:
```powershell
git status
```

Now commit the changes:
```powershell
git commit -m "feat: complete HNX26PSI09 AI SWE Agent with Web UI, file debugger & minimal diff engine"
```

---

### Step 5: Create a New Repository on GitHub

1. Open your browser and navigate to: **[https://github.com/new](https://github.com/new)**
2. Fill in the details:
   - **Repository name**: `ai-swe-agent` (or any preferred name, e.g., `ai-software-engineering-agent`)
   - **Description**: `Autonomous AI Software Engineering Agent with Web UI for HNX26PSI09 Hackathon`
   - **Visibility**: Choose **Public** (recommended for hackathon submission) or **Private**.
   - **Initialize this repository with**: **Leave ALL checkboxes unchecked** (Do NOT add README, .gitignore, or license here, as we already created them locally).
3. Click the green **Create repository** button.

---

### Step 6: Link Local Repository to GitHub Remote

Set the default branch to `main`:
```powershell
git branch -M main
```

Add your GitHub repository URL as the remote origin (replace `YOUR_USERNAME` with your actual GitHub username):

```powershell
git remote add origin https://github.com/YOUR_USERNAME/ai-swe-agent.git
```

*(If you already had an origin configured, update it using: `git remote set-url origin https://github.com/YOUR_USERNAME/ai-swe-agent.git`)*

---

### Step 7: Push to GitHub

Push your commits to GitHub:

```powershell
git push -u origin main
```

#### If prompted for credentials:
- **Username**: Enter your GitHub username.
- **Password**: Paste your **GitHub Personal Access Token** (NOT your GitHub account password, as GitHub requires tokens for Git operations).

---

### Step 8: Verify on GitHub

Open your browser and visit:
```
https://github.com/YOUR_USERNAME/ai-swe-agent
```

You should see:
- Full project structure: `agent/`, `web/`, `prompts/`, `tests/`
- Rendered `README.md` with features and architecture
- Ready for judges and collaborators to clone and run!

---

## 🔄 Making Future Updates and Pushing

Whenever you make improvements or fixes:

```powershell
# 1. Check changed files
git status

# 2. Stage changes
git add .

# 3. Commit
git commit -m "update: enhanced bug localization heuristics"

# 4. Push
git push
```

---

## ⚡ Quick Test After Cloning

Anyone cloning your repository can run it in 2 simple commands:

```bash
git clone https://github.com/YOUR_USERNAME/ai-swe-agent.git
cd ai-swe-agent
pip install -r requirements.txt
python -m uvicorn web.server:app --host 0.0.0.0 --port 8000
```
Then visit `http://localhost:8000` in any browser!
