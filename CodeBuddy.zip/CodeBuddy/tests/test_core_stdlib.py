"""
tests/test_core_stdlib.py — Tests using ONLY the Python standard library.

Run with: python -m unittest tests/test_core_stdlib.py -v
Or with:  python -m pytest tests/test_core_stdlib.py -v  (once deps are installed)

These always run regardless of whether third-party packages are installed.
They test the pure-logic portions of the agent: file scoring, diff extraction,
pytest output parsing.
"""
import re
import sys
import textwrap
import tempfile
import unittest
from pathlib import Path


# ---------------------------------------------------------------------------
# Inline copies of pure-logic functions (no imports from agent/)
# ---------------------------------------------------------------------------

def score_files(index: dict, issue: str) -> list:
    """Keyword-scoring logic from CodeUnderstander (stdlib only)."""
    stop_words = {
        "the", "a", "an", "is", "are", "was", "were", "in", "on", "at",
        "to", "for", "of", "and", "or", "not", "this", "that", "with",
        "it", "be", "by", "from", "as", "if", "when", "where", "how",
    }
    keywords = [
        w.lower()
        for w in re.split(r"\W+", issue)
        if len(w) > 2 and w.lower() not in stop_words
    ]
    scored = []
    for rel_path, content in index.items():
        content_lower = content.lower()
        path_lower = rel_path.lower()
        content_hits = sum(content_lower.count(kw) for kw in keywords)
        path_hits    = sum(3 for kw in keywords if kw in path_lower)
        test_penalty = -2 if "test" in path_lower else 0
        scored.append((rel_path, float(content_hits + path_hits + test_penalty)))
    return sorted(scored, key=lambda x: x[1], reverse=True)


def looks_like_diff(text: str) -> bool:
    """Diff-detection heuristic from BugFixer."""
    return "--- " in text and "+++ " in text and "@@ " in text


def extract_diff(text: str):
    """Diff extractor from BugFixer."""
    fence_re = re.compile(r"```(?:diff|patch)?\s*\n(.*?)```", re.DOTALL)
    match = fence_re.search(text)
    if match:
        candidate = match.group(1).strip()
        if looks_like_diff(candidate):
            return candidate
    if looks_like_diff(text.strip()):
        return text.strip()
    return None


def parse_pytest_output(output: str):
    """Pytest parser from TestRunner."""
    pattern = re.compile(r"(\d+)\s+passed|(\d+)\s+failed|(\d+)\s+error", re.IGNORECASE)
    passed = failed = errors = 0
    for m in pattern.finditer(output):
        if m.group(1):   passed  = int(m.group(1))
        elif m.group(2): failed  = int(m.group(2))
        elif m.group(3): errors  = int(m.group(3))
    return passed, failed, errors


def extract_failed_names(output: str) -> list:
    """Failed test name extractor from TestRunner."""
    names = []
    for line in output.splitlines():
        if line.startswith("FAILED "):
            name = line.replace("FAILED ", "").split(" - ")[0].strip()
            names.append(name)
    return names


def strip_diff_prefix(path: str) -> str:
    """Simulates _resolve_rel_path from PatchApplier."""
    for prefix in ("a/", "b/"):
        if path.startswith(prefix):
            path = path[2:]
    return path


# ---------------------------------------------------------------------------
# File-scoring tests
# ---------------------------------------------------------------------------

class TestFileScoring(unittest.TestCase):

    def test_relevant_file_scores_higher(self):
        index = {
            "auth/login.py": "def login(username, password): ...",
            "utils/math.py": "def add(a, b): return a + b",
        }
        scored = score_files(index, "login raises KeyError for username")
        self.assertEqual(scored[0][0], "auth/login.py")

    def test_path_keyword_match_boosts_score(self):
        index = {
            "pagination.py": "x = 1",
            "unrelated.py":  "pagination is handled here too",
        }
        scored = score_files(index, "fix pagination off-by-one")
        self.assertEqual(scored[0][0], "pagination.py")

    def test_test_files_penalised(self):
        # Use a test filename with NO keyword overlap, so the -2 penalty
        # is the only differentiator.  Both files have equal content hits.
        # xyzzy_test.py: content=4, path_hits=0, penalty=-2  → total=2
        # auth.py:       content=4, path_hits=0, penalty= 0  → total=4
        index = {
            "xyzzy_test.py": "login keyerror login keyerror",
            "auth.py":       "login keyerror login keyerror",
        }
        scored = score_files(index, "login keyerror")
        self.assertEqual(scored[0][0], "auth.py")

    def test_empty_index_returns_empty(self):
        self.assertEqual(score_files({}, "some issue"), [])

    def test_all_files_scored(self):
        index = {"a.py": "foo", "b.py": "bar", "c.py": "baz"}
        scored = score_files(index, "any issue")
        self.assertEqual(len(scored), 3)


# ---------------------------------------------------------------------------
# Diff extraction tests
# ---------------------------------------------------------------------------

class TestDiffExtraction(unittest.TestCase):

    def test_extracts_fenced_diff(self):
        response = textwrap.dedent("""\
            Here is the fix:
            ```diff
            --- a/foo.py
            +++ b/foo.py
            @@ -1,1 +1,1 @@
            -old
            +new
            ```
            That should do it.
        """)
        diff = extract_diff(response)
        self.assertIsNotNone(diff)
        self.assertIn("--- a/foo.py", diff)
        self.assertIn("+new", diff)

    def test_extracts_raw_diff(self):
        diff_text = (
            "--- a/bar.py\n"
            "+++ b/bar.py\n"
            "@@ -5,3 +5,3 @@\n"
            " context\n"
            "-broken\n"
            "+fixed\n"
            " more context\n"
        )
        self.assertIsNotNone(extract_diff(diff_text))

    def test_rejects_pure_prose(self):
        self.assertIsNone(extract_diff("This is just prose, no diff here."))

    def test_rejects_empty(self):
        self.assertIsNone(extract_diff(""))

    def test_looks_like_diff_true(self):
        self.assertTrue(looks_like_diff("--- a/x.py\n+++ b/x.py\n@@ -1 +1 @@\n-a\n+b"))

    def test_looks_like_diff_false_no_hunk(self):
        self.assertFalse(looks_like_diff("--- a/x.py\n+++ b/x.py\n"))

    def test_looks_like_diff_false_plain_text(self):
        self.assertFalse(looks_like_diff("just some text"))


# ---------------------------------------------------------------------------
# Pytest output parser tests
# ---------------------------------------------------------------------------

class TestPytestOutputParser(unittest.TestCase):

    def test_all_passed(self):
        p, f, e = parse_pytest_output("5 passed in 0.12s")
        self.assertEqual((p, f, e), (5, 0, 0))

    def test_with_failures(self):
        p, f, e = parse_pytest_output("3 passed, 2 failed, 1 error in 1.5s")
        self.assertEqual((p, f, e), (3, 2, 1))

    def test_zero_counts(self):
        p, f, e = parse_pytest_output("no tests ran")
        self.assertEqual((p, f, e), (0, 0, 0))

    def test_large_numbers(self):
        p, f, e = parse_pytest_output("100 passed, 0 failed")
        self.assertEqual(p, 100)
        self.assertEqual(f, 0)

    def test_extract_failed_names(self):
        output = (
            "FAILED tests/test_foo.py::test_bar - AssertionError: assert 1 == 2\n"
            "FAILED tests/test_baz.py::test_qux\n"
            "2 failed in 0.5s\n"
        )
        names = extract_failed_names(output)
        self.assertEqual(len(names), 2)
        self.assertIn("tests/test_foo.py::test_bar", names)
        self.assertIn("tests/test_baz.py::test_qux", names)

    def test_no_failures_returns_empty(self):
        self.assertEqual(extract_failed_names("5 passed in 0.1s"), [])


# ---------------------------------------------------------------------------
# Path helper tests
# ---------------------------------------------------------------------------

class TestPathLogic(unittest.TestCase):

    def test_strip_a_prefix(self):
        self.assertEqual(strip_diff_prefix("a/src/foo.py"), "src/foo.py")

    def test_strip_b_prefix(self):
        self.assertEqual(strip_diff_prefix("b/bar.py"), "bar.py")

    def test_no_prefix_unchanged(self):
        self.assertEqual(strip_diff_prefix("plain.py"), "plain.py")

    def test_temp_dir_write_read(self):
        tmp = Path(tempfile.mkdtemp())
        (tmp / "src").mkdir()
        (tmp / "src" / "main.py").write_text("print('hello')")
        content = (tmp / "src" / "main.py").read_text()
        self.assertIn("hello", content)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    unittest.main(verbosity=2)
