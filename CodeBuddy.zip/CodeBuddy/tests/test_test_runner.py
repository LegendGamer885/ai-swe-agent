"""
tests/test_test_runner.py — Unit tests for TestRunner framework detection and parsing.
"""

import tempfile
import textwrap
from pathlib import Path

import pytest

from agent.test_runner import TestRunner


def make_repo(files: dict) -> Path:
    tmp = Path(tempfile.mkdtemp(prefix="test_runner_repo_"))
    for rel_path, content in files.items():
        target = tmp / rel_path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
    return tmp


class TestFrameworkDetection:

    def test_detects_pytest_via_conftest(self):
        repo = make_repo({"conftest.py": ""})
        runner = TestRunner(repo)
        assert runner.detect_framework() == "pytest"

    def test_detects_pytest_via_test_file(self):
        repo = make_repo({"tests/test_something.py": "def test_foo(): pass"})
        runner = TestRunner(repo)
        assert runner.detect_framework() == "pytest"

    def test_detects_pytest_via_pytest_ini(self):
        repo = make_repo({"pytest.ini": "[pytest]\n"})
        runner = TestRunner(repo)
        assert runner.detect_framework() == "pytest"

    def test_detects_npm_via_package_json(self):
        pkg = '{"scripts": {"test": "jest"}}'
        repo = make_repo({"package.json": pkg})
        runner = TestRunner(repo)
        assert runner.detect_framework() == "npm"

    def test_detects_go_via_go_files(self):
        repo = make_repo({"main.go": "package main\n", "main_test.go": "package main\n"})
        runner = TestRunner(repo)
        assert runner.detect_framework() == "go"

    def test_no_framework_empty_repo(self):
        repo = make_repo({"README.md": "# hello"})
        runner = TestRunner(repo)
        assert runner.detect_framework() is None


class TestOutputParsers:

    def test_parse_pytest_output_all_pass(self):
        output = "5 passed in 0.12s"
        p, f, e = TestRunner._parse_pytest_output(output)
        assert p == 5
        assert f == 0
        assert e == 0

    def test_parse_pytest_output_with_failures(self):
        output = "3 passed, 2 failed, 1 error in 1.5s"
        p, f, e = TestRunner._parse_pytest_output(output)
        assert p == 3
        assert f == 2
        assert e == 1

    def test_extract_failed_test_names(self):
        output = textwrap.dedent("""\
            FAILED tests/test_foo.py::test_bar - AssertionError
            FAILED tests/test_baz.py::test_qux
            1 passed, 2 failed
        """)
        names = TestRunner._extract_failed_test_names(output)
        assert "tests/test_foo.py::test_bar" in names
        assert "tests/test_baz.py::test_qux" in names
        assert len(names) == 2

    def test_parse_jest_output(self):
        output = "Tests: 4 passed, 1 failed, 5 total"
        p, f, e = TestRunner._parse_jest_output(output)
        assert p == 4
        assert f == 1

    def test_parse_go_output(self):
        output = textwrap.dedent("""\
            --- PASS: TestAdd (0.00s)
            --- PASS: TestSub (0.00s)
            --- FAIL: TestMul (0.00s)
        """)
        p, f, e = TestRunner._parse_go_output(output)
        assert p == 2
        assert f == 1


class TestResultModel:

    def test_all_passed_true(self):
        from agent.test_runner import TestResult
        r = TestResult(
            framework="pytest", passed=5, failed=0, errors=0,
            output="", exit_code=0
        )
        assert r.all_passed is True
        assert r.total == 5

    def test_all_passed_false_on_nonzero_exit(self):
        from agent.test_runner import TestResult
        r = TestResult(
            framework="pytest", passed=5, failed=0, errors=0,
            output="", exit_code=1
        )
        assert r.all_passed is False

    def test_summary_format(self):
        from agent.test_runner import TestResult
        r = TestResult(
            framework="pytest", passed=3, failed=1, errors=0,
            output="", exit_code=1
        )
        s = r.summary()
        assert "FAIL" in s
        assert "pytest" in s
        assert "3 passed" in s
