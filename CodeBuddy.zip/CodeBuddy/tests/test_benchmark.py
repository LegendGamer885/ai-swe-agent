"""
tests/test_benchmark.py — Verify the 'What to build first' benchmark sample.
"""

import shutil
import unittest
from pathlib import Path

from agent.benchmark_sample import SAMPLE_MINIMAL_PATCH, setup_benchmark_repo
from agent.patch_applier import PatchApplier
from agent.test_runner import TestRunner


class TestBenchmarkPipeline(unittest.TestCase):

    def setUp(self):
        self.repo_path, self.issue = setup_benchmark_repo()

    def tearDown(self):
        if self.repo_path and self.repo_path.exists():
            shutil.rmtree(self.repo_path, ignore_errors=True)

    def test_benchmark_fails_before_and_passes_after(self):
        runner = TestRunner(self.repo_path)

        # Before fix: should have failing tests (documented bug)
        res_before = runner.run()
        self.assertIsNotNone(res_before)
        self.assertFalse(res_before.all_passed)
        self.assertEqual(res_before.failed, 2)
        self.assertEqual(res_before.passed, 3)

        # Apply surgical minimal patch (2 lines only)
        applier = PatchApplier(self.repo_path)
        success, msg = applier.apply(SAMPLE_MINIMAL_PATCH)
        self.assertTrue(success, f"Failed to apply patch: {msg}")

        # After fix: all 5 tests MUST pass! 0 regressions
        res_after = runner.run()
        self.assertIsNotNone(res_after)
        self.assertTrue(res_after.all_passed, f"Expected all tests to pass, output: {res_after.output}")
        self.assertEqual(res_after.passed, 5)
        self.assertEqual(res_after.failed, 0)
        self.assertEqual(res_after.errors, 0)


if __name__ == "__main__":
    unittest.main()
