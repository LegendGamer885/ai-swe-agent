"""
tests/test_llm_client.py — Unit tests for LLMClient provider logic.

Uses unittest.mock to avoid needing real API keys.
These tests use only the standard library + unittest.mock.
"""
import os
import sys
import unittest
from unittest.mock import MagicMock, patch


class TestLLMClientGemini(unittest.TestCase):
    """Test Gemini provider path using mocks."""

    def _make_gemini_client(self):
        """Build a Gemini LLMClient with all external calls mocked."""
        mock_genai = MagicMock()
        mock_model = MagicMock()
        mock_model.generate_content.return_value = MagicMock(text="Gemini response")
        mock_genai.GenerativeModel.return_value = mock_model
        mock_genai.GenerationConfig.return_value = {}

        with patch.dict(os.environ, {"GEMINI_API_KEY": "test-gemini-key"}):
            with patch.dict(sys.modules, {"google.generativeai": mock_genai}):
                # Import fresh with mocked module
                import importlib
                import agent.llm_client as llm_module
                importlib.reload(llm_module)
                client = llm_module.LLMClient(
                    provider="gemini",
                    model_name="gemini-2.0-flash",
                    _backend=mock_model,
                )
        return client, mock_model

    def test_generate_calls_backend(self):
        client, mock_model = self._make_gemini_client()
        result = client.generate("test prompt")
        mock_model.generate_content.assert_called_once_with("test prompt")
        self.assertEqual(result, "Gemini response")

    def test_provider_is_gemini(self):
        client, _ = self._make_gemini_client()
        self.assertEqual(client.provider, "gemini")


class TestLLMClientGrok(unittest.TestCase):
    """Test Grok provider path using mocks."""

    def _make_grok_client(self):
        mock_openai_cls = MagicMock()
        mock_openai_instance = MagicMock()
        mock_choice = MagicMock()
        mock_choice.message.content = "Grok response"
        mock_openai_instance.chat.completions.create.return_value = MagicMock(
            choices=[mock_choice]
        )
        mock_openai_cls.return_value = mock_openai_instance

        import agent.llm_client as llm_module
        client = llm_module.LLMClient(
            provider="grok",
            model_name="grok-3-mini",
            _backend=mock_openai_instance,
        )
        return client, mock_openai_instance

    def test_generate_calls_chat_completions(self):
        client, mock_openai = self._make_grok_client()
        result = client.generate("test prompt")
        mock_openai.chat.completions.create.assert_called_once()
        call_kwargs = mock_openai.chat.completions.create.call_args
        messages = call_kwargs.kwargs.get("messages") or call_kwargs.args[0] if call_kwargs.args else call_kwargs.kwargs["messages"]
        # Verify the prompt is in messages
        all_content = str(call_kwargs)
        self.assertIn("test prompt", all_content)
        self.assertEqual(result, "Grok response")

    def test_provider_is_grok(self):
        client, _ = self._make_grok_client()
        self.assertEqual(client.provider, "grok")

    def test_model_name_is_grok(self):
        client, _ = self._make_grok_client()
        self.assertEqual(client.model_name, "grok-3-mini")


class TestLLMClientValidation(unittest.TestCase):
    """Test provider validation logic."""

    def test_invalid_provider_raises(self):
        import agent.llm_client as llm_module
        with self.assertRaises((ValueError, Exception)):
            llm_module.LLMClient.from_env(provider="invalid_provider")

    def test_gemini_missing_key_raises(self):
        import agent.llm_client as llm_module
        env = {k: v for k, v in os.environ.items() if k != "GEMINI_API_KEY"}
        mock_genai = MagicMock()
        with patch.dict(os.environ, env, clear=True):
            with patch.dict(sys.modules, {"google.generativeai": mock_genai}):
                with self.assertRaises(EnvironmentError):
                    llm_module.LLMClient._build_gemini()

    def test_grok_missing_key_raises(self):
        import agent.llm_client as llm_module
        env = {k: v for k, v in os.environ.items() if k != "XAI_API_KEY"}
        mock_openai = MagicMock()
        with patch.dict(os.environ, env, clear=True):
            with patch.dict(sys.modules, {"openai": mock_openai}):
                with self.assertRaises(EnvironmentError):
                    llm_module.LLMClient._build_grok()

    def test_default_models_defined(self):
        import agent.llm_client as llm_module
        self.assertIn("gemini", llm_module._DEFAULT_MODELS)
        self.assertIn("grok",   llm_module._DEFAULT_MODELS)

    def test_grok_base_url(self):
        import agent.llm_client as llm_module
        self.assertEqual(llm_module._GROK_BASE_URL, "https://api.x.ai/v1")


if __name__ == "__main__":
    unittest.main(verbosity=2)
