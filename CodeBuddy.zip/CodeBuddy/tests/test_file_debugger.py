"""
tests/test_file_debugger.py — Unit tests for FileDebugger.
"""

import unittest
from agent.file_debugger import FileDebugger


class TestFileDebugger(unittest.TestCase):

    def setUp(self):
        self.debugger = FileDebugger(llm=None)  # Use heuristic / offline engine

    def test_syntax_error_colon_detection(self):
        buggy_code = "def calculate_sum(a, b)\n    return a + b\n"
        result = self.debugger.debug_file("calc.py", buggy_code)
        
        self.assertTrue(result["success"])
        self.assertIn("colon", result["what_was_wrong"].lower())
        self.assertIn(":", result["patched_content"])
        self.assertIn("--- a/calc.py", result["unified_diff"])
        self.assertIn("+++ b/calc.py", result["unified_diff"])

    def test_mutable_default_argument_fix(self):
        buggy_code = "def append_item(val, items=[]):\n    items.append(val)\n    return items\n"
        result = self.debugger.debug_file("list_mgr.py", buggy_code)
        
        self.assertTrue(result["success"])
        self.assertIn("None", result["patched_content"])
        self.assertIn("mutable default", result["what_was_wrong"].lower())
        self.assertTrue(len(result["why_it_was_wrong"]) > 0)

    def test_off_by_one_fix(self):
        buggy_code = "def get_items(seq):\n    for i in range(len(seq) + 1):\n        if i <= len(seq):\n            pass\n"
        result = self.debugger.debug_file("loop.py", buggy_code, issue_description="Fix off-by-one boundary")
        
        self.assertTrue(result["success"])
        self.assertIn("< len(seq)", result["patched_content"])
        self.assertIn("off-by-one", result["what_was_wrong"].lower())

    def test_apply_patch_to_string(self):
        original = "line 1\nline 2\nline 3\n"
        diff = """--- a/test.txt
+++ b/test.txt
@@ -1,3 +1,3 @@
 line 1
-line 2
+line 2 modified
 line 3
"""
        patched = self.debugger.apply_patch_to_string(original, "test.txt", diff)
        self.assertEqual(patched, "line 1\nline 2 modified\nline 3\n")


if __name__ == "__main__":
    unittest.main()
