"""
tests/test_patch_applier.py — Unit tests for PatchApplier.
"""

import textwrap
import tempfile
from pathlib import Path

import pytest

from agent.patch_applier import PatchApplier


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def make_repo(files: dict) -> Path:
    """Create a temporary directory with the given {rel_path: content} files."""
    tmp = Path(tempfile.mkdtemp(prefix="test_repo_"))
    for rel_path, content in files.items():
        target = tmp / rel_path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
    return tmp


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestPatchApplierBasic:

    def test_apply_simple_fix(self):
        """A one-line bug fix should be applied correctly."""
        repo = make_repo({
            "src/math_utils.py": textwrap.dedent("""\
                def add(a, b):
                    return a - b  # BUG: should be +
                """)
        })

        diff = textwrap.dedent("""\
            --- a/src/math_utils.py
            +++ b/src/math_utils.py
            @@ -1,2 +1,2 @@
             def add(a, b):
            -    return a - b  # BUG: should be +
            +    return a + b
            """)

        applier = PatchApplier(repo)
        success, msg = applier.apply(diff)

        assert success, f"Patch failed: {msg}"
        result = (repo / "src/math_utils.py").read_text()
        assert "return a + b" in result
        assert "return a - b" not in result

    def test_rollback_on_bad_diff(self):
        """A diff that references a non-existent file should fail cleanly."""
        repo = make_repo({"src/hello.py": "print('hello')\n"})

        bad_diff = textwrap.dedent("""\
            --- a/src/nonexistent.py
            +++ b/src/nonexistent.py
            @@ -1,1 +1,1 @@
            -old line
            +new line
            """)

        applier = PatchApplier(repo)
        success, msg = applier.apply(bad_diff)

        assert not success
        # Original file should be untouched
        assert (repo / "src/hello.py").read_text() == "print('hello')\n"

    def test_list_changed_files(self):
        """list_changed_files should return paths from the diff."""
        repo = make_repo({})
        diff = textwrap.dedent("""\
            --- a/src/foo.py
            +++ b/src/foo.py
            @@ -1,1 +1,1 @@
            -old
            +new
            """)
        applier = PatchApplier(repo)
        files = applier.list_changed_files(diff)
        assert "src/foo.py" in files

    def test_add_new_file(self):
        """A diff that adds a new file should create it."""
        repo = make_repo({})

        diff = textwrap.dedent("""\
            --- /dev/null
            +++ b/src/new_module.py
            @@ -0,0 +1,3 @@
            +def greet(name):
            +    return f"Hello, {name}"
            +
            """)

        applier = PatchApplier(repo)
        success, msg = applier.apply(diff)

        assert success, f"Patch failed: {msg}"
        new_file = repo / "src/new_module.py"
        assert new_file.exists()
        assert "def greet" in new_file.read_text()

    def test_invalid_diff_string(self):
        """A garbage string should not crash — just return failure."""
        repo = make_repo({"a.py": "x = 1\n"})
        applier = PatchApplier(repo)
        success, msg = applier.apply("this is not a diff at all")
        assert not success

    def test_multiline_fix(self):
        """Multiple changed lines in one hunk."""
        repo = make_repo({
            "calc.py": textwrap.dedent("""\
                def multiply(a, b):
                    result = a + b  # wrong
                    return result
                """)
        })

        diff = textwrap.dedent("""\
            --- a/calc.py
            +++ b/calc.py
            @@ -1,3 +1,3 @@
             def multiply(a, b):
            -    result = a + b  # wrong
            +    result = a * b
                 return result
            """)

        applier = PatchApplier(repo)
        success, msg = applier.apply(diff)

        assert success, msg
        content = (repo / "calc.py").read_text()
        assert "result = a * b" in content
        assert "result = a + b" not in content


class TestPatchApplierRollback:

    def test_backup_and_rollback(self):
        """After rollback, all files should be restored to pre-patch state."""
        original_content = "x = 1\n"
        repo = make_repo({"module.py": original_content})

        # Apply a valid patch
        diff = textwrap.dedent("""\
            --- a/module.py
            +++ b/module.py
            @@ -1,1 +1,1 @@
            -x = 1
            +x = 99
            """)

        applier = PatchApplier(repo)
        success, _ = applier.apply(diff)
        assert success

        # File is now changed
        assert (repo / "module.py").read_text().strip() == "x = 99"

        # Roll back
        applier.rollback()
        assert (repo / "module.py").read_text() == original_content
