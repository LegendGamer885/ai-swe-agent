"""
tests/test_web_api.py — Integration tests for FastAPI endpoints.
"""

import unittest
from fastapi.testclient import TestClient

from web.server import app


class TestWebAPI(unittest.TestCase):

    def setUp(self):
        self.client = TestClient(app)

    def test_status_endpoint(self):
        res = self.client.get("/api/status")
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertIn("active_provider", data)
        self.assertIn("available_providers", data)

    def test_debug_file_endpoint(self):
        payload = {
            "filename": "math_util.py",
            "code": "def divide(a, b)\n    return a / b\n",
            "issue_description": "Fix syntax error",
        }
        res = self.client.post("/api/debug-files", json=payload)
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertTrue(data["success"])
        self.assertIn("colon", data["what_was_wrong"].lower())
        self.assertIn("def divide(a, b):", data["patched_content"])

    def test_run_benchmark_endpoint(self):
        res = self.client.post("/api/run-benchmark")
        self.assertEqual(res.status_code, 200)
        data = res.json()
        self.assertTrue(data["success"])
        self.assertIsNotNone(data["diff"])
        self.assertIsNotNone(data["test_before"])
        self.assertIsNotNone(data["test_after"])
        self.assertEqual(data["test_before"]["failed"], 2)
        self.assertTrue(data["test_after"]["all_passed"])
        self.assertEqual(data["test_after"]["passed"], 5)


if __name__ == "__main__":
    unittest.main()
