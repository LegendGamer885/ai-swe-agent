"""
benchmark_sample.py — Generates a self-contained benchmark repository
demonstrating the "What to build first" hackathon requirement:
- Documented bug in a realistic module
- Working test suite with 2 failing tests before fix
- Passes completely (100% tests pass) after surgical minimal diff fix
- No regressions in existing working tests
"""

import difflib
import shutil
import tempfile
from pathlib import Path
from typing import Dict, Optional, Tuple

SAMPLE_BUGGY_MODULE = '''"""
pagination.py — High performance dataset paginator utility.
"""

import math
from typing import Any, Dict, List, Optional


class Paginator:
    """Paginates in-memory or queried sequences safely."""

    def __init__(self, items: List[Any], page_size: int = 10):
        if page_size <= 0:
            raise ValueError("page_size must be positive")
        self.items = items
        self.page_size = page_size

    @property
    def total_items(self) -> int:
        return len(self.items)

    @property
    def total_pages(self) -> int:
        if not self.items:
            return 1
        # BUG: Integer division truncates remainder, producing fewer pages than needed!
        # E.g. 25 items with page_size 10 produces 2 pages instead of 3.
        return self.total_items // self.page_size

    def get_page(self, page_number: int) -> Dict[str, Any]:
        """
        Return page metadata and items for 1-based page_number.
        """
        if page_number < 1:
            raise ValueError("page_number must be >= 1")

        start = (page_number - 1) * self.page_size
        end = start + self.page_size

        # BUG: Slicing without bounds check triggers out-of-range index error when requested
        if start > self.total_items:
            raise IndexError("Page start index out of bounds")

        page_items = self.items[start:end]

        return {
            "page": page_number,
            "page_size": self.page_size,
            "total_items": self.total_items,
            "total_pages": self.total_pages,
            "items": page_items,
            "has_next": page_number < self.total_pages,
            "has_prev": page_number > 1,
        }
'''

SAMPLE_FIXED_MODULE = SAMPLE_BUGGY_MODULE.replace(
    "return self.total_items // self.page_size",
    "return math.ceil(self.total_items / self.page_size)",
).replace(
    'raise IndexError("Page start index out of bounds")',
    'return {"page": page_number, "page_size": self.page_size, "total_items": self.total_items, "total_pages": self.total_pages, "items": [], "has_next": False, "has_prev": page_number > 1}',
)

SAMPLE_MINIMAL_PATCH = "".join(
    difflib.unified_diff(
        SAMPLE_BUGGY_MODULE.splitlines(keepends=True),
        SAMPLE_FIXED_MODULE.splitlines(keepends=True),
        fromfile="a/src/pagination.py",
        tofile="b/src/pagination.py",
    )
)

SAMPLE_TEST_SUITE = '''"""
test_pagination.py — Unit test suite for Paginator.
"""

import pytest
from src.pagination import Paginator


def test_basic_pagination():
    items = list(range(20))
    p = Paginator(items, page_size=5)
    page1 = p.get_page(1)
    assert page1["items"] == [0, 1, 2, 3, 4]
    assert page1["has_next"] is True
    assert page1["has_prev"] is False


def test_last_page_has_no_next():
    items = list(range(20))
    p = Paginator(items, page_size=10)
    page2 = p.get_page(2)
    assert page2["items"] == list(range(10, 20))
    assert page2["has_next"] is False
    assert page2["has_prev"] is True


def test_empty_dataset():
    p = Paginator([], page_size=10)
    page = p.get_page(1)
    assert page["items"] == []
    assert page["total_items"] == 0
    assert page["total_pages"] == 1


def test_total_pages_with_remainder():
    # DOCUMENTED BUG TEST: 25 items with page_size 10 should produce 3 pages.
    # Currently fails because total_items // page_size produces 2 instead of 3!
    items = list(range(25))
    p = Paginator(items, page_size=10)
    assert p.total_pages == 3, f"Expected 3 pages, got {p.total_pages}"
    
    # Page 3 should contain items 20-24
    page3 = p.get_page(3)
    assert page3["items"] == [20, 21, 22, 23, 24]
    assert page3["has_next"] is False


def test_out_of_bounds_returns_empty_gracefully():
    # DOCUMENTED BUG TEST: Accessing a page beyond total items should return empty items,
    # not crash with IndexError.
    items = list(range(10))
    p = Paginator(items, page_size=5)
    # Page 99 is out of bounds
    page = p.get_page(99)
    assert page["items"] == []
'''

SAMPLE_ISSUE_DESCRIPTION = (
    "Fix pagination calculation: total_pages truncates remainder causing missing last page "
    "when item count is not a multiple of page_size (e.g. 25 items / 10 page size gives 2 instead of 3), "
    "and out-of-bounds page requests raise IndexError instead of returning an empty list."
)


def setup_benchmark_repo(target_dir: Optional[Path] = None) -> Tuple[Path, str]:
    """
    Sets up a clean benchmark project directory with the documented bug and tests.
    Returns (repo_path, issue_description).
    """
    if target_dir is None:
        target_dir = Path(tempfile.mkdtemp(prefix="swe_benchmark_"))

    src_dir = target_dir / "src"
    tests_dir = target_dir / "tests"
    src_dir.mkdir(parents=True, exist_ok=True)
    tests_dir.mkdir(parents=True, exist_ok=True)

    (src_dir / "__init__.py").write_text("", encoding="utf-8")
    (tests_dir / "__init__.py").write_text("", encoding="utf-8")
    (src_dir / "pagination.py").write_text(SAMPLE_BUGGY_MODULE, encoding="utf-8")
    (tests_dir / "test_pagination.py").write_text(SAMPLE_TEST_SUITE, encoding="utf-8")
    (target_dir / "pyproject.toml").write_text(
        "[tool.pytest.ini_options]\npythonpath = [\".\"]\n", encoding="utf-8"
    )

    return target_dir, SAMPLE_ISSUE_DESCRIPTION
