"""
test_runner.py — Detects and runs the project's test suite.

Supports: pytest, unittest, Jest (npm test), Go test.
Returns structured results: how many passed/failed before and after a patch.
"""

import json
import os
import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import List, Optional, Tuple

from rich.console import Console

console = Console()


@dataclass
class TestResult:
    framework: str
    passed: int
    failed: int
    errors: int
    output: str
    exit_code: int
    test_names_failed: List[str] = field(default_factory=list)

    @property
    def total(self) -> int:
        return self.passed + self.failed + self.errors

    @property
    def all_passed(self) -> bool:
        return self.exit_code == 0 and self.failed == 0 and self.errors == 0

    def summary(self) -> str:
        status = "✓ PASS" if self.all_passed else "✗ FAIL"
        return (
            f"{status} [{self.framework}] "
            f"{self.passed} passed, {self.failed} failed, {self.errors} errors "
            f"(exit {self.exit_code})"
        )


class TestRunner:
    """Detects and runs the test suite for a repository."""

    def __init__(self, repo_path: Path):
        self.repo_path = repo_path
        self.framework: Optional[str] = None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def detect_framework(self) -> Optional[str]:
        """Detect the primary test framework used by the repo."""
        # Python: pytest preferred over unittest
        if self._has_file("pytest.ini", "setup.cfg", "pyproject.toml", "conftest.py"):
            self.framework = "pytest"
            return self.framework
        if self._has_python_tests():
            self.framework = "pytest"  # run pytest even for unittest-style tests
            return self.framework
        # Node.js / JavaScript
        pkg_json = self.repo_path / "package.json"
        if pkg_json.exists():
            try:
                pkg = json.loads(pkg_json.read_text(encoding="utf-8"))
                scripts = pkg.get("scripts", {})
                if "test" in scripts:
                    self.framework = "npm"
                    return self.framework
            except Exception:
                pass
        # Go
        if list(self.repo_path.rglob("*.go")):
            self.framework = "go"
            return self.framework

        self.framework = None
        return None

    def run(self) -> Optional[TestResult]:
        """Run the test suite. Returns None if no framework detected."""
        if self.framework is None:
            self.detect_framework()
        if self.framework is None:
            console.print("[yellow]⚠ No test framework detected.[/yellow]")
            return None

        console.print(f"[cyan]Running tests with {self.framework}...[/cyan]")
        if self.framework == "pytest":
            return self._run_pytest()
        if self.framework == "npm":
            return self._run_npm()
        if self.framework == "go":
            return self._run_go()
        return None

    # ------------------------------------------------------------------
    # Framework runners
    # ------------------------------------------------------------------

    def _run_pytest(self) -> TestResult:
        cmd = ["python", "-m", "pytest", "--tb=short", "-q", "--no-header"]
        result = self._exec(cmd)
        passed, failed, errors = self._parse_pytest_output(result.stdout + result.stderr)
        failed_names = self._extract_failed_test_names(result.stdout + result.stderr)
        return TestResult(
            framework="pytest",
            passed=passed,
            failed=failed,
            errors=errors,
            output=result.stdout + result.stderr,
            exit_code=result.returncode,
            test_names_failed=failed_names,
        )

    def _run_npm(self) -> TestResult:
        cmd = ["npm", "test", "--", "--no-coverage"]
        result = self._exec(cmd)
        passed, failed, errors = self._parse_jest_output(result.stdout + result.stderr)
        return TestResult(
            framework="jest/npm",
            passed=passed,
            failed=failed,
            errors=errors,
            output=result.stdout + result.stderr,
            exit_code=result.returncode,
        )

    def _run_go(self) -> TestResult:
        cmd = ["go", "test", "./...", "-v"]
        result = self._exec(cmd)
        passed, failed, errors = self._parse_go_output(result.stdout + result.stderr)
        return TestResult(
            framework="go test",
            passed=passed,
            failed=failed,
            errors=errors,
            output=result.stdout + result.stderr,
            exit_code=result.returncode,
        )

    # ------------------------------------------------------------------
    # Output parsers
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_pytest_output(output: str) -> Tuple[int, int, int]:
        # Matches: "5 passed, 2 failed, 1 error"
        pattern = re.compile(
            r"(\d+)\s+passed|(\d+)\s+failed|(\d+)\s+error",
            re.IGNORECASE,
        )
        passed = failed = errors = 0
        for m in pattern.finditer(output):
            if m.group(1):
                passed = int(m.group(1))
            elif m.group(2):
                failed = int(m.group(2))
            elif m.group(3):
                errors = int(m.group(3))
        return passed, failed, errors

    @staticmethod
    def _extract_failed_test_names(output: str) -> List[str]:
        """Extract FAILED test::name lines from pytest output."""
        names = []
        for line in output.splitlines():
            if line.startswith("FAILED "):
                name = line.replace("FAILED ", "").split(" - ")[0].strip()
                names.append(name)
        return names

    @staticmethod
    def _parse_jest_output(output: str) -> Tuple[int, int, int]:
        passed = failed = errors = 0
        for line in output.splitlines():
            m = re.search(r"Tests:\s+(\d+)\s+passed", line)
            if m:
                passed = int(m.group(1))
            m = re.search(r"(\d+)\s+failed", line)
            if m:
                failed = int(m.group(1))
        return passed, failed, errors

    @staticmethod
    def _parse_go_output(output: str) -> Tuple[int, int, int]:
        passed = output.count("--- PASS")
        failed = output.count("--- FAIL")
        errors = output.count("FAIL\t")
        return passed, failed, errors

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _exec(self, cmd: List[str]) -> subprocess.CompletedProcess:
        return subprocess.run(
            cmd,
            capture_output=True,
            text=True,
            cwd=str(self.repo_path),
            env={**os.environ},
        )

    def _has_file(self, *names: str) -> bool:
        return any((self.repo_path / n).exists() for n in names)

    def _has_python_tests(self) -> bool:
        return any(self.repo_path.rglob("test_*.py")) or any(
            self.repo_path.rglob("*_test.py")
        )
