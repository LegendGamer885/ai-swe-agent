"""
reporter.py — Formats and prints the final bug-fix report to the terminal.
"""

from typing import List, Optional

from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.syntax import Syntax
from rich.table import Table
from rich import box

from agent.test_runner import TestResult

console = Console()


class Reporter:
    """Produces a rich terminal report summarising the fix."""

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def report_fix(
        self,
        issue: str,
        understanding: str,
        diff: Optional[str],
        changed_files: List[str],
        before: Optional[TestResult],
        after: Optional[TestResult],
        patch_success: bool,
        patch_message: str,
        rolled_back: bool,
    ):
        console.rule("[bold blue]AI Software Engineering Agent — Report[/bold blue]")

        # Issue
        console.print(
            Panel(issue, title="[bold]Issue / Bug Description[/bold]", border_style="blue")
        )

        # Understanding
        console.print(
            Panel(
                Markdown(understanding),
                title="[bold]Codebase Analysis[/bold]",
                border_style="cyan",
            )
        )

        # Diff
        if diff:
            console.print(
                Panel(
                    Syntax(diff, "diff", theme="monokai", line_numbers=True),
                    title="[bold]Patch (Unified Diff)[/bold]",
                    border_style="green" if patch_success else "red",
                )
            )
        else:
            console.print(
                Panel(
                    "[yellow]No diff was generated.[/yellow]",
                    title="[bold]Patch[/bold]",
                    border_style="yellow",
                )
            )

        # Patch application status
        status_color = "green" if patch_success and not rolled_back else "red"
        status_icon = "✓" if patch_success and not rolled_back else "✗"
        status_label = "Applied" if patch_success and not rolled_back else (
            "Rolled Back" if rolled_back else "Failed"
        )
        console.print(
            f"\n[{status_color}]{status_icon} Patch Status: {status_label}[/{status_color}]"
            + (f" — {patch_message}" if patch_message else "")
        )

        # Changed files
        if changed_files:
            console.print("\n[bold]Files Changed:[/bold]")
            for f in changed_files:
                console.print(f"  [green]•[/green] {f}")

        # Test comparison table
        if before is not None or after is not None:
            self._print_test_table(before, after)

        # Regression warning
        if before and after and not after.all_passed and before.all_passed:
            console.print(
                Panel(
                    "[bold red]⚠ REGRESSION DETECTED[/bold red]\n"
                    "Tests that passed before the patch are now failing.\n"
                    "The patch has been [bold]rolled back[/bold] automatically.",
                    border_style="red",
                )
            )
        elif after and after.all_passed:
            console.print(
                Panel(
                    "[bold green]✓ All tests pass after the patch.[/bold green]",
                    border_style="green",
                )
            )

        console.rule()

    def report_explanation(self, query: str, explanation: str):
        console.rule("[bold blue]AI Software Engineering Agent — Explanation[/bold blue]")
        console.print(Panel(query, title="[bold]Query[/bold]", border_style="blue"))
        console.print(
            Panel(Markdown(explanation), title="[bold]Explanation[/bold]", border_style="cyan")
        )
        console.rule()

    def report_tests_only(self, result: Optional[TestResult]):
        console.rule("[bold blue]Test Results[/bold blue]")
        if result is None:
            console.print("[yellow]No test framework detected.[/yellow]")
        else:
            console.print(result.summary())
            if result.test_names_failed:
                console.print("\n[red]Failed tests:[/red]")
                for name in result.test_names_failed:
                    console.print(f"  [red]•[/red] {name}")
            console.print(
                Panel(result.output[-3000:], title="Test Output", border_style="dim")
            )
        console.rule()

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    @staticmethod
    def _print_test_table(before: Optional[TestResult], after: Optional[TestResult]):
        table = Table(
            title="Test Results — Before vs After",
            box=box.ROUNDED,
            show_header=True,
            header_style="bold magenta",
        )
        table.add_column("Metric", style="bold")
        table.add_column("Before Patch", justify="right")
        table.add_column("After Patch", justify="right")

        def fmt(result: Optional[TestResult], attr: str) -> str:
            if result is None:
                return "[dim]N/A[/dim]"
            return str(getattr(result, attr, "—"))

        def color_delta(before_val: Optional[TestResult], after_val: Optional[TestResult], attr: str, good_if: str = "low") -> str:
            if before_val is None or after_val is None:
                return fmt(after_val, attr)
            b = getattr(before_val, attr, 0)
            a = getattr(after_val, attr, 0)
            val = str(a)
            if good_if == "low":
                if a < b:
                    return f"[green]{val}[/green]"
                elif a > b:
                    return f"[red]{val}[/red]"
            else:
                if a > b:
                    return f"[green]{val}[/green]"
                elif a < b:
                    return f"[red]{val}[/red]"
            return val

        table.add_row("Passed",  fmt(before, "passed"),  color_delta(before, after, "passed",  "high"))
        table.add_row("Failed",  fmt(before, "failed"),  color_delta(before, after, "failed",  "low"))
        table.add_row("Errors",  fmt(before, "errors"),  color_delta(before, after, "errors",  "low"))
        table.add_row("Exit Code", fmt(before, "exit_code"), fmt(after, "exit_code"))

        before_status = ("[green]✓ PASS[/green]" if before and before.all_passed else "[red]✗ FAIL[/red]") if before else "[dim]N/A[/dim]"
        after_status  = ("[green]✓ PASS[/green]" if after  and after.all_passed  else "[red]✗ FAIL[/red]") if after  else "[dim]N/A[/dim]"
        table.add_row("Overall", before_status, after_status)

        console.print(table)
