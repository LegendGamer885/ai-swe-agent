"""
patch_applier.py — Applies a unified diff patch to the repository safely.

Strategy:
  1. Parse the diff with `unidiff` to find all target files.
  2. Back up each target file.
  3. Apply the patch using Python's subprocess (patch utility) or
     a pure-Python fallback line-by-line applier.
  4. If anything fails, roll back ALL files to their backups.
"""

import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import unidiff
from rich.console import Console

console = Console()


class PatchApplier:
    """Applies a unified diff patch to a repository with full rollback support."""

    def __init__(self, repo_path: Path):
        self.repo_path = repo_path
        self._backups: Dict[str, Path] = {}  # rel_path -> backup file path

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def apply(self, diff_text: str) -> Tuple[bool, str]:
        """
        Apply the unified diff to the repo.
        Returns (success: bool, message: str).
        """
        # 1. Parse and validate the diff
        try:
            patch_set = unidiff.PatchSet(diff_text)
        except Exception as exc:
            return False, f"Failed to parse diff: {exc}"

        if not patch_set:
            return False, "Diff parsed but contains no file changes."

        # 2. Validate all target files exist (for modifications)
        for patched_file in patch_set:
            if patched_file.is_modified_file or patched_file.is_removed_file:
                target = self.repo_path / patched_file.path
                if not target.exists():
                    # Try source_file path (--- a/path)
                    src_path = patched_file.source_file.lstrip("ab/").lstrip("/")
                    target = self.repo_path / src_path
                    if not target.exists():
                        return False, f"Target file not found: {patched_file.path}"

        # 3. Create backups
        self._backups.clear()
        self._create_backups(patch_set)

        # 4. Apply patch
        success, msg = self._apply_patch(diff_text)
        if not success:
            console.print(f"[red]Patch failed: {msg}[/red]")
            self.rollback()
            return False, msg

        console.print(f"[green]✓ Patch applied successfully.[/green]")
        return True, "Patch applied successfully."

    def rollback(self):
        """Restore all backed-up files to their pre-patch state."""
        if not self._backups:
            return
        console.print("[yellow]Rolling back changes...[/yellow]")
        for rel_path, backup_path in self._backups.items():
            target = self.repo_path / rel_path
            try:
                shutil.copy2(backup_path, target)
                console.print(f"  [dim]Restored {rel_path}[/dim]")
            except Exception as exc:
                console.print(f"  [red]Failed to restore {rel_path}: {exc}[/red]")
        console.print("[yellow]Rollback complete.[/yellow]")

    def list_changed_files(self, diff_text: str) -> List[str]:
        """Return list of relative file paths touched by the diff."""
        try:
            patch_set = unidiff.PatchSet(diff_text)
            return [pf.path for pf in patch_set]
        except Exception:
            return []

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _create_backups(self, patch_set: unidiff.PatchSet):
        tmp_dir = Path(tempfile.mkdtemp(prefix="ai_swe_backup_"))
        for patched_file in patch_set:
            rel_path = self._resolve_rel_path(patched_file)
            target = self.repo_path / rel_path
            if target.exists():
                backup = tmp_dir / rel_path.replace("/", "__")
                shutil.copy2(target, backup)
                self._backups[rel_path] = backup

    def _apply_patch(self, diff_text: str) -> Tuple[bool, str]:
        """Try system `patch` first; fall back to pure-Python applier."""
        if shutil.which("patch"):
            return self._apply_via_system_patch(diff_text)
        return self._apply_pure_python(diff_text)

    def _apply_via_system_patch(self, diff_text: str) -> Tuple[bool, str]:
        """Use the system `patch` command."""
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".diff", delete=False, encoding="utf-8"
        ) as f:
            f.write(diff_text)
            diff_file = f.name

        try:
            result = subprocess.run(
                ["patch", "-p1", "--input", diff_file, "--directory", str(self.repo_path)],
                capture_output=True,
                text=True,
            )
            if result.returncode == 0:
                return True, result.stdout
            return False, result.stderr or result.stdout
        except FileNotFoundError:
            return self._apply_pure_python(diff_text)
        finally:
            Path(diff_file).unlink(missing_ok=True)

    def _apply_pure_python(self, diff_text: str) -> Tuple[bool, str]:
        """Pure-Python unified diff applier using the unidiff library."""
        try:
            patch_set = unidiff.PatchSet(diff_text)
        except Exception as exc:
            return False, str(exc)

        for patched_file in patch_set:
            rel_path = self._resolve_rel_path(patched_file)
            target = self.repo_path / rel_path

            if patched_file.is_added_file:
                target.parent.mkdir(parents=True, exist_ok=True)
                lines = [str(line.value) for hunk in patched_file for line in hunk if not line.is_removed]
                target.write_text("".join(lines), encoding="utf-8")

            elif patched_file.is_removed_file:
                if target.exists():
                    target.unlink()

            else:  # modified
                if not target.exists():
                    return False, f"Cannot patch missing file: {rel_path}"
                original_lines = target.read_text(encoding="utf-8").splitlines(keepends=True)
                try:
                    patched_lines = self._apply_hunks(original_lines, patched_file)
                except ValueError as exc:
                    return False, f"Hunk mismatch in {rel_path}: {exc}"
                target.write_text("".join(patched_lines), encoding="utf-8")

        return True, "Applied via pure-Python applier."

    @staticmethod
    def _apply_hunks(original_lines: List[str], patched_file) -> List[str]:
        """Apply hunks from a unidiff PatchedFile to original_lines."""
        result = list(original_lines)
        offset = 0
        for hunk in patched_file:
            src_start = hunk.source_start - 1 + offset  # 0-indexed
            removed = [line for line in hunk if line.is_removed or line.is_context]
            added = [line for line in hunk if line.is_added or line.is_context]

            # Verify context matches
            src_lines = result[src_start : src_start + len(removed)]
            for i, (expected, actual) in enumerate(zip(removed, src_lines)):
                if expected.is_context and str(expected.value) != actual:
                    raise ValueError(
                        f"Context mismatch at line {src_start + i + 1}: "
                        f"expected {expected.value!r}, got {actual!r}"
                    )

            # Replace
            result[src_start : src_start + hunk.source_length] = [
                str(line.value) for line in hunk if not line.is_removed
            ]
            offset += hunk.target_length - hunk.source_length

        return result

    @staticmethod
    def _resolve_rel_path(patched_file) -> str:
        """Strip a/ b/ prefixes from diff paths."""
        path = patched_file.path
        # unidiff usually strips these, but just in case:
        for prefix in ("a/", "b/"):
            if path.startswith(prefix):
                path = path[2:]
        return path
