"""
file_debugger.py — Debugs user-uploaded files surgically without rewriting the whole file.

Features:
- Direct uploaded code file analysis (Python, JS, TS, HTML, Go, JSON, etc.)
- Strict minimal unified diff generation (touches only faulty lines)
- Structured diagnostic reports:
    1. What was wrong
    2. Why it was wrong
    3. How it was fixed
- Pure-python diff application to produce the updated file
- Offline AST & heuristic analyzer fallback when no API key is provided
"""

import ast
import difflib
import re
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from agent.llm_client import LLMClient


_DIFF_BLOCK_RE = re.compile(r"```(?:diff|patch)?\s*\n(.*?)```", re.DOTALL)
_WHAT_RE = re.compile(r"### WHAT WAS WRONG\s*\n(.*?)(?=### WHY IT WAS WRONG|\Z)", re.DOTALL | re.IGNORECASE)
_WHY_RE = re.compile(r"### WHY IT WAS WRONG\s*\n(.*?)(?=### HOW IT WAS FIXED|\Z)", re.DOTALL | re.IGNORECASE)
_HOW_RE = re.compile(r"### HOW IT WAS FIXED\s*\n(.*?)(?=### UNIFIED DIFF|\Z)", re.DOTALL | re.IGNORECASE)


class FileDebugger:
    """Surgically diagnoses and fixes bugs in uploaded files."""

    def __init__(self, llm: Optional[LLMClient] = None):
        self.llm = llm

    def debug_file(
        self,
        filename: str,
        content: str,
        issue_description: str = "",
        error_log: str = "",
    ) -> Dict[str, Any]:
        """
        Debug an uploaded file and produce:
        - what_was_wrong
        - why_it_was_wrong
        - how_it_was_fixed
        - unified_diff
        - patched_content
        - changed_line_count
        """
        # If an LLM client is available, try LLM first
        if self.llm is not None:
            try:
                result = self._debug_with_llm(filename, content, issue_description, error_log)
                if result.get("unified_diff"):
                    return result
            except Exception as e:
                # Fall back to heuristic engine if LLM request failed
                pass

        # Heuristic / Offline Engine
        return self._debug_with_heuristics(filename, content, issue_description, error_log)

    def _debug_with_llm(
        self,
        filename: str,
        content: str,
        issue_description: str,
        error_log: str,
    ) -> Dict[str, Any]:
        prompt = f"""You are an expert AI Software Engineering Agent.
Your goal is to surgically fix a bug in the provided file WITHOUT rewriting the whole file.

Target File: {filename}
```
{content}
```

Issue / Bug Description:
{issue_description or "Analyze the code, find any bugs or syntax/logic errors, and fix them."}

Error Log / Traceback (if provided):
{error_log or "None provided."}

RULES:
1. DO NOT rewrite the entire file.
2. Only change the minimal number of lines required to fix the bug.
3. Output the fix as a valid unified diff (starting with --- a/{filename} and +++ b/{filename}).
4. Clearly explain what was wrong and why it was wrong.

Format your response EXACTLY as follows:

### WHAT WAS WRONG
[Clear 1-3 sentences describing what the bug was]

### WHY IT WAS WRONG
[Detailed explanation of the root cause, why the previous code broke or behaved incorrectly]

### HOW IT WAS FIXED
[Summary of the surgical fix made]

### UNIFIED DIFF
```diff
--- a/{filename}
+++ b/{filename}
@@ ... @@
- [old line]
+ [fixed line]
```
"""
        response = self.llm.generate(prompt)

        what_match = _WHAT_RE.search(response)
        why_match = _WHY_RE.search(response)
        how_match = _HOW_RE.search(response)
        diff_match = _DIFF_BLOCK_RE.search(response)

        what = what_match.group(1).strip() if what_match else "Bug diagnosed in source logic."
        why = why_match.group(1).strip() if why_match else "The code caused unexpected runtime errors or incorrect output."
        how = how_match.group(1).strip() if how_match else "Applied surgical fix to the affected statements."
        diff = diff_match.group(1).strip() if diff_match else ""

        if not diff and "--- " in response and "+++ " in response:
            diff = response.strip()

        patched_content = self.apply_patch_to_string(content, filename, diff) if diff else content

        return {
            "filename": filename,
            "original_content": content,
            "patched_content": patched_content,
            "unified_diff": diff,
            "what_was_wrong": what,
            "why_it_was_wrong": why,
            "how_it_was_fixed": how,
            "provider": getattr(self.llm, "provider", "llm"),
            "success": bool(diff and patched_content != content),
        }

    def _debug_with_heuristics(
        self,
        filename: str,
        content: str,
        issue_description: str,
        error_log: str,
    ) -> Dict[str, Any]:
        """Offline smart analyzer for common bugs and syntax errors."""
        lines = content.splitlines(keepends=True)
        patched_lines = list(lines)
        what = ""
        why = ""
        how = ""

        # 1. Check Python Syntax Error via AST
        if filename.endswith(".py"):
            try:
                ast.parse(content, filename=filename)
            except SyntaxError as syn_err:
                err_lineno = syn_err.lineno or 1
                faulty_line = lines[err_lineno - 1] if err_lineno <= len(lines) else ""
                
                # Check missing colon
                fixed_line = faulty_line
                if not faulty_line.rstrip().endswith(":") and any(
                    faulty_line.lstrip().startswith(kw) for kw in ["def ", "class ", "if ", "elif ", "else", "for ", "while ", "try", "except", "finally", "with "]
                ):
                    fixed_line = faulty_line.rstrip() + ":\n"
                    what = f"SyntaxError at line {err_lineno}: Missing colon at end of statement."
                    why = f"In Python, compound statements ({faulty_line.strip().split()[0]}) require a trailing colon `:` to define a new block."
                    how = f"Appended `:` to line {err_lineno}."

                # Check unclosed parentheses/quotes or print statement without parens
                elif "print " in faulty_line and "(" not in faulty_line:
                    indent = len(faulty_line) - len(faulty_line.lstrip())
                    expr = faulty_line.strip()[len("print "):]
                    fixed_line = (" " * indent) + f"print({expr})\n"
                    what = f"SyntaxError at line {err_lineno}: Python 2 style print statement."
                    why = "In Python 3+, print is a function and requires parentheses around arguments."
                    how = f"Wrapped argument in parentheses: `print(...)`."
                else:
                    what = f"SyntaxError at line {err_lineno}: {syn_err.msg}"
                    why = f"Python parser failed at line {err_lineno} column {syn_err.offset}: invalid syntax structure."
                    how = "Corrected syntax error."

                if fixed_line != faulty_line:
                    patched_lines[err_lineno - 1] = fixed_line

        # 2. Check for common logic bugs (off-by-one, integer division in pagination, mutable default args)
        if not what:
            combined_desc = (issue_description + " " + error_log).lower()
            
            # Check integer division truncation in pagination / count
            for i, line in enumerate(lines):
                if "//" in line and ("page" in line.lower() or "paginate" in combined_desc):
                    indent = len(line) - len(line.lstrip())
                    lead = " " * indent
                    patched_lines[i] = re.sub(r"(\b\w+\b)\s*//\s*(\b\w+\b)", r"math.ceil(\1 / \2)", line)
                    if not any("import math" in l for l in lines):
                        patched_lines.insert(0, "import math\n")
                    what = f"Integer division truncates remainder at line {i+1}."
                    why = "Using `//` truncates the division result downwards, omitting the final page when total items is not an exact multiple."
                    how = "Replaced floor division with `math.ceil(... / ...)` to account for partial pages."
                    break

                # Check index out of bounds check
                if "indexerror" in combined_desc or "bounds" in combined_desc:
                    if "raise indexerror" in line.lower() and "start >" in lines[max(0, i-1)].lower():
                        indent = len(line) - len(line.lstrip())
                        lead = " " * indent
                        patched_lines[i] = f"{lead}return []\n"
                        what = f"Unchecked slice bounds raised IndexError at line {i+1}."
                        why = "Querying out-of-range offsets threw an unhandled IndexError instead of gracefully returning an empty list."
                        how = "Replaced IndexError raise with safe empty list return."
                        break

                # Check off-by-one <= vs <
                if "off-by-one" in combined_desc or "boundary" in combined_desc:
                    if "<=" in line and "len(" in line:
                        patched_lines[i] = line.replace("<=", "<")
                        what = f"Off-by-one boundary comparison (`<= len(...)`) at line {i+1}."
                        why = "Sequence indices are 0-based; index `len(seq)` is out of range, causing an IndexError at the upper boundary."
                        how = "Changed operator from `<=` to `<`."
                        break

                # Check mutable default argument `def fn(x=[])`
                if re.search(r"def \w+\([^)]*=\s*(\[\]|\{\})", line):
                    match = re.search(r"(\w+)\s*=\s*(\[\]|\{\})", line)
                    if match:
                        param = match.group(1)
                        patched_lines[i] = line.replace(match.group(0), f"{param}=None")
                        indent = len(lines[i+1]) - len(lines[i+1].lstrip()) if i+1 < len(lines) else 4
                        lead = " " * indent
                        default_val = "[]" if "[]" in match.group(0) else "{}"
                        patched_lines.insert(i + 1, f"{lead}if {param} is None:\n{lead}    {param} = {default_val}\n")
                        what = f"Dangerous mutable default argument `{match.group(0)}` at line {i+1}."
                        why = "Default parameter values are evaluated once at function definition time, persisting mutations across function invocations."
                        how = f"Set default to `None` and initialized `{param} = {default_val}` inside the function body."
                        break

        # Fallback if no specific pattern matched
        if not what:
            what = "Issue detected in logic or parameter handling."
            why = f"Execution deviated from expected contract described in: '{issue_description or 'bug report'}'."
            how = "Code reviewed; please provide API key or additional error log details for deep model generation."

        patched_content = "".join(patched_lines)
        diff = self._create_unified_diff(content, patched_content, filename)

        return {
            "filename": filename,
            "original_content": content,
            "patched_content": patched_content,
            "unified_diff": diff,
            "what_was_wrong": what,
            "why_it_was_wrong": why,
            "how_it_was_fixed": how,
            "provider": "offline-heuristic-analyzer",
            "success": bool(diff and patched_content != content),
        }

    @staticmethod
    def _create_unified_diff(original: str, patched: str, filename: str) -> str:
        orig_lines = original.splitlines(keepends=True)
        patched_lines = patched.splitlines(keepends=True)
        diff_lines = list(
            difflib.unified_diff(
                orig_lines,
                patched_lines,
                fromfile=f"a/{filename}",
                tofile=f"b/{filename}",
            )
        )
        return "".join(diff_lines)

    @staticmethod
    def apply_patch_to_string(original: str, filename: str, diff_text: str) -> str:
        """Applies a unified diff to a source string safely."""
        try:
            import unidiff
            patch_set = unidiff.PatchSet(diff_text)
            orig_lines = original.splitlines(keepends=True)
            
            # Simple line-by-line patch application
            for patched_file in patch_set:
                result_lines = []
                orig_idx = 0
                for hunk in patched_file:
                    target_start = hunk.source_start - 1
                    while orig_idx < target_start and orig_idx < len(orig_lines):
                        result_lines.append(orig_lines[orig_idx])
                        orig_idx += 1
                    
                    for line in hunk:
                        if line.is_added:
                            result_lines.append(line.value)
                        elif line.is_removed:
                            orig_idx += 1
                        elif line.is_context:
                            if orig_idx < len(orig_lines):
                                result_lines.append(orig_lines[orig_idx])
                                orig_idx += 1
                
                while orig_idx < len(orig_lines):
                    result_lines.append(orig_lines[orig_idx])
                    orig_idx += 1
                return "".join(result_lines)
        except Exception:
            pass
        return original
