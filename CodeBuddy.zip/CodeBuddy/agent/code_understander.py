"""
code_understander.py — Uses an LLMClient to understand the codebase and select
the most relevant files for a given issue/query.
"""

import re
from pathlib import Path
from typing import Dict, List, Tuple

from rich.console import Console

from agent.llm_client import LLMClient

console = Console()

# Maximum number of files to include in a single LLM context
MAX_CONTEXT_FILES = 12
# Maximum total characters sent to the LLM per call
MAX_CONTEXT_CHARS = 120_000


class CodeUnderstander:
    """Selects relevant files and builds codebase understanding via an LLM."""

    def __init__(self, llm: LLMClient, prompts_dir: Path):
        self.llm = llm
        self.prompts_dir = prompts_dir

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def select_relevant_files(
        self,
        index: Dict[str, str],
        issue: str,
        max_files: int = MAX_CONTEXT_FILES,
    ) -> List[str]:
        """
        Score all files in the index by relevance to the issue and return
        the top-N relative paths.
        """
        scored = self._score_files(index, issue)
        top = sorted(scored, key=lambda x: x[1], reverse=True)[:max_files]
        selected = [path for path, _ in top]
        console.print(
            f"[cyan]Selected {len(selected)} relevant file(s):[/cyan] "
            + ", ".join(selected[:5])
            + ("..." if len(selected) > 5 else "")
        )
        return selected

    def understand(
        self,
        index: Dict[str, str],
        relevant_files: List[str],
        issue: str,
    ) -> str:
        """
        Send relevant file contents + issue to the LLM.
        Returns a structured understanding string.
        """
        prompt_template = (self.prompts_dir / "understand.txt").read_text(encoding="utf-8")
        context_block = self._build_context(index, relevant_files)
        prompt = prompt_template.format(context=context_block, issue=issue)

        console.print(f"[cyan]Asking {self.llm.provider} to understand the codebase...[/cyan]")
        return self.llm.generate(prompt)

    def explain(
        self,
        index: Dict[str, str],
        relevant_files: List[str],
        query: str,
    ) -> str:
        """
        Explain how a piece of the codebase works in response to a free-form query.
        """
        prompt_template = (self.prompts_dir / "explain.txt").read_text(encoding="utf-8")
        context_block = self._build_context(index, relevant_files)
        prompt = prompt_template.format(context=context_block, query=query)

        console.print(f"[cyan]Asking {self.llm.provider} to explain the code...[/cyan]")
        return self.llm.generate(prompt)

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _score_files(self, index: Dict[str, str], issue: str) -> List[Tuple[str, float]]:
        """
        Score files by keyword overlap with the issue. Simple but effective
        for narrowing context before the LLM call.
        """
        stop_words = {
            "the", "a", "an", "is", "are", "was", "were", "in", "on", "at",
            "to", "for", "of", "and", "or", "not", "this", "that", "with",
            "it", "be", "by", "from", "as", "if", "when", "where", "how",
        }
        keywords = [
            w.lower()
            for w in re.split(r"\W+", issue)
            if len(w) > 2 and w.lower() not in stop_words
        ]

        scored = []
        for rel_path, content in index.items():
            content_lower = content.lower()
            path_lower = rel_path.lower()

            content_hits = sum(content_lower.count(kw) for kw in keywords)
            path_hits = sum(3 for kw in keywords if kw in path_lower)
            test_penalty = -2 if "test" in path_lower else 0

            score = content_hits + path_hits + test_penalty
            scored.append((rel_path, float(score)))

        return scored

    def _build_context(self, index: Dict[str, str], relevant_files: List[str]) -> str:
        """
        Concatenate file contents into a fenced code block context string,
        respecting the MAX_CONTEXT_CHARS budget.
        """
        parts = []
        total_chars = 0
        for rel_path in relevant_files:
            content = index.get(rel_path, "")
            header = f"\n\n### FILE: {rel_path}\n```\n"
            footer = "\n```\n"
            chunk = header + content + footer
            if total_chars + len(chunk) > MAX_CONTEXT_CHARS:
                remaining = MAX_CONTEXT_CHARS - total_chars - len(header) - len(footer)
                if remaining > 200:
                    chunk = header + content[:remaining] + "\n[...truncated...]\n" + footer
                else:
                    break
            parts.append(chunk)
            total_chars += len(chunk)
        return "".join(parts)
