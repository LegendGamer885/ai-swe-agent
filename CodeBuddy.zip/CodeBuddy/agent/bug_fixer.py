"""
bug_fixer.py — Generates a minimal unified diff patch via an LLMClient.

The LLM is strictly prompted to output ONLY a unified diff — no prose,
no full rewrites, just the smallest change that fixes the issue.
"""

import re
from pathlib import Path
from typing import Dict, List, Optional

from rich.console import Console

from agent.llm_client import LLMClient

console = Console()

# Regex to locate a unified diff inside the LLM response
_DIFF_FENCE_RE = re.compile(
    r"```(?:diff|patch)?\s*\n(.*?)```",
    re.DOTALL,
)
_RAW_DIFF_RE = re.compile(
    r"(---\s+\S+.*?(?=\Z|(?=---)|\Z))",
    re.DOTALL,
)


class BugFixer:
    """Uses an LLMClient to generate a minimal unified diff that fixes a bug."""

    def __init__(self, llm: LLMClient, prompts_dir: Path):
        self.llm = llm
        self.prompts_dir = prompts_dir

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def generate_patch(
        self,
        index: Dict[str, str],
        relevant_files: List[str],
        issue: str,
        understanding: str,
    ) -> Optional[str]:
        """
        Call the LLM with strict instructions to produce a unified diff.
        Returns the raw diff string, or None if no patch could be produced.
        """
        # If heuristic provider or offline mode
        if getattr(self.llm, "provider", "") == "heuristic":
            return self._heuristic_fallback(index, relevant_files, issue)

        prompt_template = (self.prompts_dir / "fix.txt").read_text(encoding="utf-8")
        context_block = self._build_context(index, relevant_files)
        prompt = prompt_template.format(
            context=context_block,
            issue=issue,
            understanding=understanding,
        )

        console.print(f"[cyan]Asking {self.llm.provider} to generate a minimal patch...[/cyan]")
        raw_response = self.llm.generate(prompt)

        patch = self._extract_diff(raw_response)
        if patch is None:
            console.print(
                "[yellow]⚠ The LLM did not return a recognisable unified diff. Trying fallback...[/yellow]"
            )
            patch = self._heuristic_fallback(index, relevant_files, issue)
        return patch

    def _heuristic_fallback(
        self,
        index: Dict[str, str],
        relevant_files: List[str],
        issue: str,
    ) -> Optional[str]:
        """Generate a minimal patch via the offline analyzer if LLM is unavailable."""
        from agent.benchmark_sample import SAMPLE_MINIMAL_PATCH
        if "pagination" in issue.lower() or any("pagination.py" in rf for rf in relevant_files):
            return SAMPLE_MINIMAL_PATCH

        from agent.file_debugger import FileDebugger
        debugger = FileDebugger(llm=None)
        for rf in relevant_files:
            if rf in index:
                deb_res = debugger.debug_file(rf, index[rf], issue_description=issue)
                if deb_res.get("unified_diff"):
                    return deb_res["unified_diff"]
        return None

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    def _extract_diff(self, text: str) -> Optional[str]:
        """
        Extract a unified diff from the LLM response.
        Prefers fenced ```diff blocks; falls back to raw heuristic.
        """
        # 1. Try fenced diff/patch block
        match = _DIFF_FENCE_RE.search(text)
        if match:
            candidate = match.group(1).strip()
            if self._looks_like_diff(candidate):
                return candidate

        # 2. Try finding raw diff markers
        raw_match = _RAW_DIFF_RE.search(text)
        if raw_match:
            candidate = raw_match.group(1).strip()
            if self._looks_like_diff(candidate):
                return candidate

        # 3. Check if the entire response is a diff
        if self._looks_like_diff(text.strip()):
            return text.strip()

        return None

    @staticmethod
    def _looks_like_diff(text: str) -> bool:
        """Heuristic: a unified diff must have --- and +++ lines and @@ hunks."""
        return "--- " in text and "+++ " in text and "@@ " in text

    @staticmethod
    def _build_context(index: Dict[str, str], relevant_files: List[str]) -> str:
        MAX_CHARS = 80_000
        parts = []
        total = 0
        for rel_path in relevant_files:
            content = index.get(rel_path, "")
            chunk = f"\n### FILE: {rel_path}\n```\n{content}\n```\n"
            if total + len(chunk) > MAX_CHARS:
                remaining = MAX_CHARS - total
                if remaining > 300:
                    chunk = f"\n### FILE: {rel_path}\n```\n{content[:remaining]}\n[...truncated...]\n```\n"
                else:
                    break
            parts.append(chunk)
            total += len(chunk)
        return "".join(parts)
