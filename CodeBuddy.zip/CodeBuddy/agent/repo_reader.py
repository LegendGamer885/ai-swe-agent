"""
repo_reader.py — Clone or read a local repository, build a file index.
"""

import os
import shutil
import tempfile
from pathlib import Path
from typing import Dict, List, Optional

import git
from rich.console import Console

console = Console()

# File extensions we consider source code
SOURCE_EXTENSIONS = {
    ".py", ".js", ".ts", ".jsx", ".tsx", ".java", ".go", ".rb",
    ".rs", ".c", ".cpp", ".h", ".cs", ".php", ".swift", ".kt",
    ".scala", ".sh", ".bash", ".yaml", ".yml", ".toml", ".json",
    ".html", ".css", ".sql", ".md",
}

# Directories to always skip
SKIP_DIRS = {
    ".git", "__pycache__", "node_modules", ".venv", "venv", "env",
    ".env", "dist", "build", ".mypy_cache", ".pytest_cache",
    ".tox", "coverage", ".coverage", "htmlcov", "*.egg-info",
}

# Max file size to read (bytes) — skip giant generated files
MAX_FILE_BYTES = 100_000


class RepoReader:
    """Reads a repository (URL or local path) and indexes its source files."""

    def __init__(self, repo_source: str):
        self.repo_source = repo_source
        self.repo_path: Optional[Path] = None
        self._cloned_tmp: Optional[str] = None  # track temp dir for cleanup

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def load(self) -> Path:
        """Clone (if URL) or validate (if local path). Returns repo root path."""
        if self._looks_like_url(self.repo_source):
            self.repo_path = self._clone(self.repo_source)
        else:
            local = Path(self.repo_source).resolve()
            if not local.exists():
                raise FileNotFoundError(f"Local path not found: {local}")
            self.repo_path = local
        return self.repo_path

    def build_file_index(self) -> Dict[str, str]:
        """
        Walk the repo and return {relative_path: file_content} for all
        readable source files under MAX_FILE_BYTES.
        """
        if self.repo_path is None:
            raise RuntimeError("Call load() before build_file_index().")

        index: Dict[str, str] = {}
        for fpath in self._walk_source_files(self.repo_path):
            rel = fpath.relative_to(self.repo_path).as_posix()
            try:
                content = fpath.read_text(encoding="utf-8", errors="replace")
                index[rel] = content
            except Exception as exc:
                console.print(f"[yellow]⚠ Skipped {rel}: {exc}[/yellow]")
        return index

    def get_test_files(self, index: Dict[str, str]) -> List[str]:
        """Return relative paths that look like test files."""
        tests = []
        for rel_path in index:
            name = Path(rel_path).name
            if (
                name.startswith("test_")
                or name.endswith("_test.py")
                or name.endswith(".test.js")
                or name.endswith(".spec.js")
                or name.endswith(".test.ts")
                or name.endswith(".spec.ts")
                or "/tests/" in rel_path
                or "/test/" in rel_path
            ):
                tests.append(rel_path)
        return tests

    def cleanup(self):
        """Remove the temporary cloned directory (if any)."""
        if self._cloned_tmp and os.path.exists(self._cloned_tmp):
            shutil.rmtree(self._cloned_tmp, ignore_errors=True)
            console.print("[dim]Cleaned up temporary clone.[/dim]")

    # ------------------------------------------------------------------
    # Internals
    # ------------------------------------------------------------------

    @staticmethod
    def _looks_like_url(s: str) -> bool:
        return s.startswith("http://") or s.startswith("https://") or s.startswith("git@")

    def _clone(self, url: str) -> Path:
        tmp = tempfile.mkdtemp(prefix="ai_swe_")
        self._cloned_tmp = tmp
        console.print(f"[cyan]Cloning {url} ...[/cyan]")
        try:
            git.Repo.clone_from(url, tmp, depth=1)
        except git.GitCommandError as exc:
            shutil.rmtree(tmp, ignore_errors=True)
            raise RuntimeError(f"Git clone failed: {exc}") from exc
        console.print(f"[green]✓ Cloned to {tmp}[/green]")
        return Path(tmp)

    def _walk_source_files(self, root: Path) -> List[Path]:
        results = []
        for dirpath, dirnames, filenames in os.walk(root):
            # Prune skip dirs in-place so os.walk won't descend into them
            dirnames[:] = [
                d for d in dirnames
                if d not in SKIP_DIRS and not d.startswith(".")
            ]
            for fname in filenames:
                fpath = Path(dirpath) / fname
                if fpath.suffix.lower() in SOURCE_EXTENSIONS:
                    if fpath.stat().st_size <= MAX_FILE_BYTES:
                        results.append(fpath)
        return results
