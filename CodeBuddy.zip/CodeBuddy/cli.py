#!/usr/bin/env python3
"""
cli.py — AI Software Engineering Agent CLI

Commands:
  fix      Clone/read a repo, fix a bug, run tests, report results.
  explain  Explain how a piece of a codebase works.
  test     Run the repo's test suite and report results.

Providers:
  --provider gemini   Google Gemini (default) — needs GEMINI_API_KEY in .env
  --provider grok     xAI Grok                — needs XAI_API_KEY in .env

Usage:
  python cli.py fix --repo <url_or_path> --issue "description"
  python cli.py fix --repo <url_or_path> --issue "description" --provider grok
  python cli.py explain --repo <url_or_path> --query "how does auth work?"
  python cli.py test --repo <url_or_path>
"""

import sys
from pathlib import Path

import click
from dotenv import load_dotenv
from rich.console import Console

# Load .env if present
load_dotenv()

console = Console()

# Resolve the prompts directory relative to this file
PROMPTS_DIR = Path(__file__).parent / "prompts"

# Valid LLM providers
PROVIDERS = click.Choice(["gemini", "grok", "openai", "heuristic"], case_sensitive=False)


def _get_llm(provider: str):
    """Build and return an LLMClient, exiting cleanly on missing API key."""
    from agent.llm_client import LLMClient
    try:
        return LLMClient.from_env(provider=provider)
    except EnvironmentError as exc:
        console.print(f"[bold red]Error:[/bold red] {exc}")
        sys.exit(1)


# ---------------------------------------------------------------------------
# CLI group
# ---------------------------------------------------------------------------

@click.group()
def cli():
    """AI Software Engineering Agent — fix bugs surgically, never rewrite."""


# ---------------------------------------------------------------------------
# fix command
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--repo",     required=True, help="GitHub URL or local path to the repository.")
@click.option("--issue",    required=True, help="Bug description or feature request.")
@click.option("--provider", default="gemini", type=PROVIDERS, show_default=True,
              help="LLM provider: 'gemini' (GEMINI_API_KEY) or 'grok' (XAI_API_KEY).")
@click.option("--no-tests", is_flag=True, default=False, help="Skip running tests.")
@click.option("--dry-run",  is_flag=True, default=False,
              help="Generate patch but do not apply it.")
@click.option("--max-files", default=12, show_default=True,
              help="Max source files to send to the LLM.")
def fix(repo: str, issue: str, provider: str, no_tests: bool, dry_run: bool, max_files: int):
    """
    Read a repository, understand it, and apply a minimal patch to fix the issue.

    \b
    Examples:
      # Using Grok (default in this example)
      python cli.py fix --repo https://github.com/you/repo \\
                        --issue "Login raises KeyError for usernames with spaces" \\
                        --provider grok

      # Using Gemini
      python cli.py fix --repo ./my-project --issue "Off-by-one in pagination"

      # Dry run — see the patch without applying it
      python cli.py fix --repo ./my-project --issue "Fix null check" --dry-run
    """
    from agent.repo_reader import RepoReader
    from agent.code_understander import CodeUnderstander
    from agent.bug_fixer import BugFixer
    from agent.patch_applier import PatchApplier
    from agent.test_runner import TestRunner
    from agent.reporter import Reporter

    llm      = _get_llm(provider)
    reporter = Reporter()
    temp_demo_path = None

    try:
        # ── 1. Load repo ───────────────────────────────────────────────
        if repo.strip().lower() in ("demo", "benchmark"):
            from agent.benchmark_sample import setup_benchmark_repo
            repo_path, demo_issue = setup_benchmark_repo()
            temp_demo_path = repo_path
            reader = RepoReader(str(repo_path))
            reader.repo_path = repo_path
            if not issue:
                issue = demo_issue
        else:
            reader = RepoReader(repo)
            repo_path = reader.load()
        console.print(f"[green]✓ Repo loaded:[/green] {repo_path}")

        # ── 2. Index source files ──────────────────────────────────────
        console.print("[cyan]Indexing source files...[/cyan]")
        index = reader.build_file_index()
        console.print(f"[green]✓ Indexed {len(index)} source files.[/green]")

        # ── 3. Select relevant files + understand ──────────────────────
        understander   = CodeUnderstander(llm, PROMPTS_DIR)
        relevant_files = understander.select_relevant_files(index, issue, max_files)
        understanding  = understander.understand(index, relevant_files, issue)

        # ── 4. Run tests BEFORE patch ──────────────────────────────────
        test_runner   = TestRunner(repo_path)
        before_result = None
        if not no_tests:
            before_result = test_runner.run()
            if before_result:
                console.print(f"[dim]Before:[/dim] {before_result.summary()}")

        # ── 5. Generate patch ──────────────────────────────────────────
        fixer = BugFixer(llm, PROMPTS_DIR)
        diff  = fixer.generate_patch(index, relevant_files, issue, understanding)

        if diff is None:
            console.print("[yellow]No patch generated. The agent could not produce a valid diff.[/yellow]")
            reporter.report_fix(
                issue=issue, understanding=understanding, diff=None,
                changed_files=[], before=before_result, after=None,
                patch_success=False,
                patch_message="LLM did not return a valid unified diff.",
                rolled_back=False,
            )
            return

        if dry_run:
            console.print("[yellow]--dry-run: patch not applied.[/yellow]")
            reporter.report_fix(
                issue=issue, understanding=understanding, diff=diff,
                changed_files=[], before=before_result, after=None,
                patch_success=False, patch_message="Dry run — patch not applied.",
                rolled_back=False,
            )
            return

        # ── 6. Apply patch ─────────────────────────────────────────────
        applier       = PatchApplier(repo_path)
        changed_files = applier.list_changed_files(diff)
        success, msg  = applier.apply(diff)

        # ── 7. Run tests AFTER patch ───────────────────────────────────
        after_result = None
        rolled_back  = False
        if not no_tests and success:
            after_result = test_runner.run()
            if after_result:
                console.print(f"[dim]After:[/dim]  {after_result.summary()}")

            # Regression check
            if before_result and before_result.all_passed and after_result and not after_result.all_passed:
                console.print("[bold red]⚠ Regression detected! Rolling back patch...[/bold red]")
                applier.rollback()
                rolled_back = True

        # ── 8. Report ──────────────────────────────────────────────────
        reporter.report_fix(
            issue=issue, understanding=understanding, diff=diff,
            changed_files=changed_files, before=before_result, after=after_result,
            patch_success=success and not rolled_back,
            patch_message=msg, rolled_back=rolled_back,
        )

    finally:
        reader.cleanup()


# ---------------------------------------------------------------------------
# explain command
# ---------------------------------------------------------------------------

@cli.command()
@click.option("--repo",     required=True, help="GitHub URL or local path to the repository.")
@click.option("--query",    required=True, help="What you want to understand about the codebase.")
@click.option("--provider", default="gemini", type=PROVIDERS, show_default=True,
              help="LLM provider: 'gemini' or 'grok'.")
@click.option("--max-files", default=10, show_default=True,
              help="Max source files to send to the LLM.")
def explain(repo: str, query: str, provider: str, max_files: int):
    """
    Explain how part of a codebase works.

    \b
    Examples:
      python cli.py explain --repo ./my-project \\
                            --query "How does the authentication middleware work?" \\
                            --provider grok
    """
    from agent.repo_reader import RepoReader
    from agent.code_understander import CodeUnderstander
    from agent.reporter import Reporter

    llm      = _get_llm(provider)
    reader   = RepoReader(repo)
    reporter = Reporter()

    try:
        repo_path      = reader.load()
        index          = reader.build_file_index()
        understander   = CodeUnderstander(llm, PROMPTS_DIR)
        relevant_files = understander.select_relevant_files(index, query, max_files)
        explanation    = understander.explain(index, relevant_files, query)
        reporter.report_explanation(query=query, explanation=explanation)
    finally:
        reader.cleanup()


# ---------------------------------------------------------------------------
# test command
# ---------------------------------------------------------------------------

@cli.command(name="test")
@click.option("--repo", required=True, help="GitHub URL or local path to the repository.")
def run_tests(repo: str):
    """
    Run the repository's existing test suite and report results.

    \b
    Example:
      python cli.py test --repo ./my-project
    """
    from agent.repo_reader import RepoReader
    from agent.test_runner import TestRunner
    from agent.reporter import Reporter

    reader   = RepoReader(repo)
    reporter = Reporter()

    try:
        repo_path = reader.load()
        runner    = TestRunner(repo_path)
        result    = runner.run()
        reporter.report_tests_only(result)
    finally:
        reader.cleanup()


# ---------------------------------------------------------------------------
# serve command
# ---------------------------------------------------------------------------

@cli.command(name="serve")
@click.option("--host", default="127.0.0.1", show_default=True, help="Host to bind the web server.")
@click.option("--port", default=8000, show_default=True, type=int, help="Port for the web server.")
@click.option("--reload", is_flag=True, default=False, help="Enable auto-reload on code change.")
def serve(host: str, port: int, reload: bool):
    """
    Launch the AI Software Engineering Agent Web Application.

    \b
    Example:
      python cli.py serve
      python cli.py serve --port 8080
    """
    import uvicorn
    console.print(f"[bold green]Starting Web UI at http://{host}:{port}[/bold green]")
    uvicorn.run("web.server:app", host=host, port=port, reload=reload)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    cli()

