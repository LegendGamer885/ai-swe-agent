"""
conftest.py — pytest configuration and fixtures.

When third-party packages (click, rich, unidiff, etc.) are not installed,
integration tests that import them are automatically skipped.
"""
import sys
import pytest


def pytest_collection_modifyitems(config, items):
    """
    Mark tests that require third-party packages as skipped
    when those packages are not available in the environment.
    """
    missing = []
    for pkg in ("click", "rich", "unidiff", "git", "dotenv", "google.generativeai"):
        try:
            __import__(pkg.replace(".", "/").replace("/", "."))
        except ImportError:
            missing.append(pkg)

    if missing:
        skip_marker = pytest.mark.skip(
            reason=f"Third-party packages not installed: {', '.join(missing)}. "
                   "Run: pip install -r requirements.txt"
        )
        for item in items:
            # Skip tests in agent/* and tests/* that rely on these packages
            if "test_patch_applier" in item.nodeid or "test_test_runner" in item.nodeid:
                item.add_marker(skip_marker)
