/**
 * app.js — Frontend controller for AI Software Engineering Agent
 */

let currentRepoDiff = "";
let currentFileDiff = "";
let currentPatchedContent = "";
let currentPatchedFilename = "";

document.addEventListener("DOMContentLoaded", () => {
  fetchAppStatus();
  setupDragAndDrop();
});

// ---------------------------------------------------------------------------
// Tabs
// ---------------------------------------------------------------------------

function switchTab(tabId) {
  document.querySelectorAll(".tab-pane").forEach(el => el.classList.add("hidden"));
  document.querySelectorAll(".tab-btn").forEach(el => {
    el.classList.remove("active", "bg-surface-700", "text-white");
    el.classList.add("text-slate-400");
  });

  const pane = document.getElementById(`pane-${tabId}`);
  const btn = document.getElementById(`tab-${tabId}`);
  if (pane) pane.classList.remove("hidden");
  if (btn) {
    btn.classList.add("active", "bg-surface-700", "text-white");
    btn.classList.remove("text-slate-400");
  }
}

// ---------------------------------------------------------------------------
// Settings Modal & API
// ---------------------------------------------------------------------------

function openSettingsModal() {
  document.getElementById("settings-modal").classList.remove("hidden");
}

function closeSettingsModal() {
  document.getElementById("settings-modal").classList.add("hidden");
}

function onProviderChanged() {
  const p = document.getElementById("modal-provider").value;
  const keyGroup = document.getElementById("modal-key-group");
  const keyLabel = document.getElementById("modal-key-label");
  if (p === "heuristic") {
    keyGroup.classList.add("hidden");
  } else {
    keyGroup.classList.remove("hidden");
    keyLabel.innerText = `${p.toUpperCase()} API Key`;
  }
}

async function fetchAppStatus() {
  try {
    const res = await fetch("/api/status");
    if (!res.ok) return;
    const data = await res.json();
    const provider = data.active_provider || "gemini";
    document.getElementById("active-provider-label").innerText = `Model: ${capitalize(provider)}`;
    document.getElementById("modal-provider").value = provider;
    onProviderChanged();
  } catch (err) {
    console.error("Failed to load status:", err);
  }
}

async function saveSettings() {
  const provider = document.getElementById("modal-provider").value;
  const apiKey = document.getElementById("modal-api-key").value;

  const payload = { provider };
  if (provider === "gemini") payload.gemini_key = apiKey;
  if (provider === "openai") payload.openai_key = apiKey;
  if (provider === "grok") payload.grok_key = apiKey;
  if (provider === "anthropic") payload.anthropic_key = apiKey;

  try {
    const res = await fetch("/api/settings", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (res.ok) {
      document.getElementById("active-provider-label").innerText = `Model: ${capitalize(provider)}`;
      closeSettingsModal();
    }
  } catch (err) {
    alert("Failed to save settings: " + err);
  }
}

// ---------------------------------------------------------------------------
// TAB 1: GITHUB REPO FIXER
// ---------------------------------------------------------------------------

function loadSampleRepo() {
  document.getElementById("repo-url").value = "demo";
  document.getElementById("repo-issue").value =
    "Fix pagination calculation: total_pages truncates remainder causing missing last page (e.g. 25 items / 10 page size gives 2 instead of 3), and out-of-bounds page requests raise IndexError instead of returning an empty list.";
}

async function triggerFixRepo() {
  const repo = document.getElementById("repo-url").value.trim();
  const issue = document.getElementById("repo-issue").value.trim();
  const runTests = document.getElementById("repo-run-tests").checked;
  const dryRun = document.getElementById("repo-dry-run").checked;

  if (!repo) {
    alert("Please enter a GitHub repository URL or type 'demo'.");
    return;
  }
  if (!issue) {
    alert("Please enter a bug description or issue.");
    return;
  }

  // UI state
  const btn = document.getElementById("btn-fix-repo");
  btn.disabled = true;
  btn.classList.add("opacity-60");

  const progressBox = document.getElementById("repo-progress-box");
  const emptyPlaceholder = document.getElementById("repo-empty-placeholder");
  const resultsCard = document.getElementById("repo-results-card");
  
  progressBox.classList.remove("hidden");
  emptyPlaceholder.classList.add("hidden");
  resultsCard.classList.add("hidden");

  updateRepoProgress("Step 1/5: Loading & indexing codebase...", 20);

  try {
    const response = await fetch("/api/fix-repo", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        repo,
        issue,
        run_tests: runTests,
        dry_run: dryRun,
      }),
    });

    updateRepoProgress("Step 4/5: Running tests & validating patch...", 80);

    if (!response.ok) {
      const err = await response.json();
      throw new Error(err.detail || "Server error occurred");
    }

    const data = await response.json();
    updateRepoProgress("Step 5/5: Completed successfully!", 100);

    setTimeout(() => {
      progressBox.classList.add("hidden");
      resultsCard.classList.remove("hidden");
      displayRepoResults(data);
    }, 600);

  } catch (err) {
    alert("Error fixing repository: " + err.message);
    progressBox.classList.add("hidden");
    emptyPlaceholder.classList.remove("hidden");
  } finally {
    btn.disabled = false;
    btn.classList.remove("opacity-60");
  }
}

function updateRepoProgress(text, pct) {
  document.getElementById("repo-status-detail").innerText = text;
  document.getElementById("repo-progress-bar").style.width = `${pct}%`;
}

function displayRepoResults(data) {
  currentRepoDiff = data.diff || "";

  // Test Badges
  const beforeBadge = document.getElementById("test-before-badge");
  const beforeSummary = document.getElementById("test-before-summary");
  if (data.test_before) {
    beforeBadge.innerText = data.test_before.all_passed ? "Passed" : "Failed";
    beforeBadge.className = data.test_before.all_passed
      ? "px-2 py-0.5 rounded text-xs font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
      : "px-2 py-0.5 rounded text-xs font-semibold bg-rose-500/20 text-rose-400 border border-rose-500/30";
    beforeSummary.innerText = data.test_before.summary;
  } else {
    beforeBadge.innerText = "Skipped";
    beforeSummary.innerText = "Tests skipped or no test suite detected";
  }

  const afterBadge = document.getElementById("test-after-badge");
  const afterSummary = document.getElementById("test-after-summary");
  if (data.test_after) {
    afterBadge.innerText = data.test_after.all_passed ? "All Passed ✓" : "Failed";
    afterBadge.className = data.test_after.all_passed
      ? "px-2 py-0.5 rounded text-xs font-semibold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
      : "px-2 py-0.5 rounded text-xs font-semibold bg-rose-500/20 text-rose-400 border border-rose-500/30";
    afterSummary.innerText = data.test_after.summary;
  } else {
    afterBadge.innerText = data.patch_applied ? "Applied" : "Dry Run";
    afterSummary.innerText = data.message;
  }

  // What & Why & How
  document.getElementById("repo-what-wrong").innerText = data.what_was_wrong || "Boundary condition bug in calculation logic.";
  document.getElementById("repo-why-wrong").innerText = data.why_it_was_wrong || "The code violated bounds checking or expected return values.";
  document.getElementById("repo-how-fixed").innerText = data.how_it_was_fixed || "Applied minimal surgical patch with no rewrites.";

  // Diff
  const container = document.getElementById("repo-diff-container");
  container.innerHTML = renderDiff(data.diff);
  lucide.createIcons();
}

function copyRepoDiff() {
  if (currentRepoDiff) {
    navigator.clipboard.writeText(currentRepoDiff);
    alert("Unified diff copied to clipboard!");
  }
}

// ---------------------------------------------------------------------------
// TAB 2: FILE UPLOAD DEBUGGER
// ---------------------------------------------------------------------------

function setupDragAndDrop() {
  const dropZone = document.getElementById("drop-zone");
  const fileInput = document.getElementById("file-input");

  if (!dropZone || !fileInput) return;

  dropZone.addEventListener("click", () => fileInput.click());

  dropZone.addEventListener("dragover", (e) => {
    e.preventDefault();
    dropZone.classList.add("border-emerald-500");
  });

  dropZone.addEventListener("dragleave", () => {
    dropZone.classList.remove("border-emerald-500");
  });

  dropZone.addEventListener("drop", (e) => {
    e.preventDefault();
    dropZone.classList.remove("border-emerald-500");
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      handleUploadedFile(e.dataTransfer.files[0]);
    }
  });

  fileInput.addEventListener("change", (e) => {
    if (e.target.files && e.target.files.length > 0) {
      handleUploadedFile(e.target.files[0]);
    }
  });
}

function handleUploadedFile(file) {
  document.getElementById("file-name").value = file.name;
  document.getElementById("file-size-badge").innerText = `${(file.size / 1024).toFixed(1)} KB`;

  const reader = new FileReader();
  reader.onload = (e) => {
    document.getElementById("file-code").value = e.target.result;
  };
  reader.readAsText(file);
}

function loadSampleFile() {
  document.getElementById("file-name").value = "array_processor.py";
  document.getElementById("file-code").value = `def calculate_average(scores=[]):
    """Calculate average of test scores."""
    total = 0
    for i in range(len(scores) + 1):
        total += scores[i]
    return total // len(scores)
`;
  document.getElementById("file-issue").value =
    "Fix IndexError on loop boundary and remove dangerous mutable default argument `scores=[]`";
}

async function triggerDebugFile() {
  const filename = document.getElementById("file-name").value.trim();
  const code = document.getElementById("file-code").value;
  const issue = document.getElementById("file-issue").value.trim();

  if (!code.trim()) {
    alert("Please provide or upload source code to debug.");
    return;
  }

  const btn = document.getElementById("btn-debug-file");
  btn.disabled = true;
  btn.classList.add("opacity-60");

  try {
    const res = await fetch("/api/debug-files", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        filename,
        code,
        issue_description: issue,
      }),
    });

    if (!res.ok) {
      throw new Error("Debugging request failed");
    }

    const data = await res.json();
    currentFileDiff = data.unified_diff || "";
    currentPatchedContent = data.patched_content || "";
    currentPatchedFilename = data.filename || "fixed_code.py";

    // Show Results
    document.getElementById("file-empty-placeholder").classList.add("hidden");
    const resCard = document.getElementById("file-results-card");
    resCard.classList.remove("hidden");

    document.getElementById("file-what-wrong").innerText = data.what_was_wrong;
    document.getElementById("file-why-wrong").innerText = data.why_it_was_wrong;
    document.getElementById("file-how-fixed").innerText = data.how_it_was_fixed;

    document.getElementById("file-diff-container").innerHTML = renderDiff(data.unified_diff);
    document.getElementById("file-patched-preview").innerText = data.patched_content;

    lucide.createIcons();

  } catch (err) {
    alert("Error debugging file: " + err.message);
  } finally {
    btn.disabled = false;
    btn.classList.remove("opacity-60");
  }
}

function copyFileDiff() {
  if (currentFileDiff) {
    navigator.clipboard.writeText(currentFileDiff);
    alert("Unified diff copied to clipboard!");
  }
}

function downloadPatchedFile() {
  if (!currentPatchedContent) return;
  const blob = new Blob([currentPatchedContent], { type: "text/plain;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = currentPatchedFilename || "fixed_code.py";
  a.click();
}

// ---------------------------------------------------------------------------
// TAB 3: 1-CLICK BENCHMARK DEMO
// ---------------------------------------------------------------------------

async function runOneClickBenchmark() {
  const btn = document.getElementById("btn-run-benchmark");
  btn.disabled = true;
  btn.innerHTML = `<i data-lucide="loader" class="w-4 h-4 animate-spin"></i><span>Running Benchmark...</span>`;
  lucide.createIcons();

  try {
    const res = await fetch("/api/run-benchmark", { method: "POST" });
    if (!res.ok) throw new Error("Benchmark execution failed");
    const data = await res.json();

    const area = document.getElementById("benchmark-results-area");
    area.classList.remove("hidden");

    if (data.test_before) {
      document.getElementById("bm-before-summary").innerText = data.test_before.summary;
    }
    if (data.test_after) {
      document.getElementById("bm-after-summary").innerText = data.test_after.summary;
    }

    document.getElementById("bm-diff-container").innerHTML = renderDiff(data.diff);
    lucide.createIcons();

  } catch (err) {
    alert("Benchmark failed: " + err.message);
  } finally {
    btn.disabled = false;
    btn.innerHTML = `<i data-lucide="zap" class="w-4 h-4 fill-current"></i><span>Execute 1-Click Benchmark</span>`;
    lucide.createIcons();
  }
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function capitalize(s) {
  if (!s) return "";
  return s.charAt(0).toUpperCase() + s.slice(1);
}

function copySnippet(btn) {
  const code = btn.parentElement.querySelector("pre").innerText;
  navigator.clipboard.writeText(code);
  const oldText = btn.innerText;
  btn.innerText = "Copied!";
  setTimeout(() => (btn.innerText = oldText), 2000);
}
