/**
 * diff_viewer.js — Renders unified diffs into cleanly highlighted HTML blocks.
 */

function renderDiff(diffText) {
  if (!diffText || !diffText.trim()) {
    return '<div class="text-slate-500 italic p-3">No diff changes generated.</div>';
  }

  const lines = diffText.split('\n');
  let html = '';

  for (let line of lines) {
    const escaped = escapeHtml(line);
    if (line.startsWith('---') || line.startsWith('+++')) {
      html += `<div class="diff-line diff-line-file">${escaped}</div>`;
    } else if (line.startsWith('@@')) {
      html += `<div class="diff-line diff-line-header">${escaped}</div>`;
    } else if (line.startsWith('+')) {
      html += `<div class="diff-line diff-line-added">${escaped}</div>`;
    } else if (line.startsWith('-')) {
      html += `<div class="diff-line diff-line-removed">${escaped}</div>`;
    } else {
      html += `<div class="diff-line diff-line-context">${escaped}</div>`;
    }
  }

  return html;
}

function escapeHtml(text) {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
