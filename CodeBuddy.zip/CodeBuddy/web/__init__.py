"""Web module for AI Software Engineering Agent."""
