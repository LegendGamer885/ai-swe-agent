"""
web/server.py — FastAPI backend for the AI Software Engineering Agent Web Application.

Provides REST endpoints for:
- Repository bug fixing with pre/post test verification and rollback
- Single & multi-file upload debugging with minimal unified diffs
- One-click benchmark demo (the Hackathon "What to build first" documented bug)
- Live test execution
- Dynamic LLM provider configuration (Gemini, OpenAI, Grok, Anthropic, Ollama, Heuristic)
"""

import os
import shutil
import tempfile
import traceback
from pathlib import Path
from typing import Any, Dict, List, Optional

from dotenv import load_dotenv
load_dotenv()

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from agent.benchmark_sample import setup_benchmark_repo
from agent.bug_fixer import BugFixer
from agent.code_understander import CodeUnderstander
from agent.file_debugger import FileDebugger
from agent.llm_client import LLMClient, _DEFAULT_MODELS
from agent.patch_applier import PatchApplier
from agent.repo_reader import RepoReader
from agent.test_runner import TestResult, TestRunner

BASE_DIR = Path(__file__).resolve().parent.parent
STATIC_DIR = BASE_DIR / "web" / "static"
PROMPTS_DIR = BASE_DIR / "prompts"

app = FastAPI(
    title="AI Software Engineering Agent",
    description="Autonomous codebase bug fixer, test verifier, and file debugger.",
    version="2.0.0",
)

# Enable CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global runtime configuration state
RUN_CONFIG: Dict[str, Any] = {
    "provider": "gemini" if os.environ.get("GEMINI_API_KEY") else ("grok" if os.environ.get("XAI_API_KEY") else "heuristic"),
    "api_keys": {
        "gemini": os.environ.get("GEMINI_API_KEY", ""),
        "grok": os.environ.get("XAI_API_KEY", ""),
        "openai": os.environ.get("OPENAI_API_KEY", ""),
        "anthropic": os.environ.get("ANTHROPIC_API_KEY", ""),
    },
    "model": "",
}


def _get_active_llm(override_provider: Optional[str] = None, override_key: Optional[str] = None) -> LLMClient:
    provider = (override_provider or RUN_CONFIG["provider"]).lower()
    key = override_key or RUN_CONFIG["api_keys"].get(provider) or os.environ.get(f"{provider.upper()}_API_KEY")

    if provider == "heuristic" or not key:
        return LLMClient(provider="heuristic", model_name="rule-engine")

    try:
        return LLMClient.build_client(provider=provider, api_key=key, model_name=RUN_CONFIG.get("model") or None)
    except Exception as exc:
        print(f"Error creating LLMClient for {provider}: {exc}. Falling back to heuristic.")
        return LLMClient(provider="heuristic", model_name="rule-engine")


def _format_test_result(res: Optional[TestResult]) -> Optional[Dict[str, Any]]:
    if res is None:
        return None
    return {
        "framework": res.framework,
        "passed": res.passed,
        "failed": res.failed,
        "errors": res.errors,
        "total": res.total,
        "all_passed": res.all_passed,
        "exit_code": res.exit_code,
        "output": res.output,
        "summary": res.summary(),
        "test_names_failed": res.test_names_failed,
    }


# -----------------------------------------------------------------------------
# Request Schemas
# -----------------------------------------------------------------------------

class FixRepoRequest(BaseModel):
    repo: str
    issue: str
    provider: Optional[str] = None
    api_key: Optional[str] = None
    run_tests: bool = True
    dry_run: bool = False
    max_files: int = 12


class SettingsRequest(BaseModel):
    provider: Optional[str] = None
    gemini_key: Optional[str] = None
    openai_key: Optional[str] = None
    grok_key: Optional[str] = None
    anthropic_key: Optional[str] = None
    model_name: Optional[str] = None


class DebugCodeRequest(BaseModel):
    filename: str
    code: str
    issue_description: Optional[str] = ""
    error_log: Optional[str] = ""
    provider: Optional[str] = None
    api_key: Optional[str] = None


# -----------------------------------------------------------------------------
# REST Endpoints
# -----------------------------------------------------------------------------

@app.get("/api/status")
def get_status():
    """Get active configuration, available providers, and environment keys."""
    has_gemini = bool(RUN_CONFIG["api_keys"].get("gemini") or os.environ.get("GEMINI_API_KEY"))
    has_grok = bool(RUN_CONFIG["api_keys"].get("grok") or os.environ.get("XAI_API_KEY"))
    has_openai = bool(RUN_CONFIG["api_keys"].get("openai") or os.environ.get("OPENAI_API_KEY"))

    return {
        "active_provider": RUN_CONFIG["provider"],
        "active_model": RUN_CONFIG.get("model") or _DEFAULT_MODELS.get(RUN_CONFIG["provider"], "default"),
        "available_providers": ["gemini", "openai", "grok", "anthropic", "ollama", "heuristic"],
        "keys_configured": {
            "gemini": has_gemini,
            "grok": has_grok,
            "openai": has_openai,
            "anthropic": bool(RUN_CONFIG["api_keys"].get("anthropic")),
        },
    }


@app.post("/api/settings")
def update_settings(req: SettingsRequest):
    """Update API keys or active provider in memory."""
    if req.provider:
        RUN_CONFIG["provider"] = req.provider.lower()
    if req.gemini_key is not None:
        RUN_CONFIG["api_keys"]["gemini"] = req.gemini_key
    if req.openai_key is not None:
        RUN_CONFIG["api_keys"]["openai"] = req.openai_key
    if req.grok_key is not None:
        RUN_CONFIG["api_keys"]["grok"] = req.grok_key
    if req.anthropic_key is not None:
        RUN_CONFIG["api_keys"]["anthropic"] = req.anthropic_key
    if req.model_name is not None:
        RUN_CONFIG["model"] = req.model_name

    return {"status": "updated", "config": RUN_CONFIG["provider"]}


@app.post("/api/fix-repo")
def fix_repository(req: FixRepoRequest):
    """
    Main autonomous agent endpoint:
    1. Reads/clones repo
    2. Runs pre-fix tests
    3. Indexes & ranks files
    4. Generates minimal unified diff via LLM
    5. Applies patch
    6. Runs post-fix tests
    7. Rollback if regression occurs
    8. Returns diagnostic report
    """
    llm = _get_active_llm(req.provider, req.api_key)
    is_benchmark = (req.repo.strip().lower() in ("demo", "benchmark", "sample"))

    temp_repo_path: Optional[Path] = None
    reader: Optional[RepoReader] = None

    try:
        if is_benchmark:
            repo_path, issue_text = setup_benchmark_repo()
            temp_repo_path = repo_path
            issue = req.issue.strip() if req.issue.strip() else issue_text
        else:
            issue = req.issue.strip()
            reader = RepoReader(req.repo.strip())
            repo_path = reader.load()

        # Step 1: Run pre-patch tests
        before_test: Optional[TestResult] = None
        if req.run_tests:
            runner_before = TestRunner(repo_path)
            before_test = runner_before.run()

        # Step 2: Build index and select relevant files
        local_reader = RepoReader(str(repo_path))
        local_reader.repo_path = repo_path
        index = local_reader.build_file_index()

        if not index:
            raise HTTPException(status_code=400, detail="Repository contains no readable source files.")

        understander = CodeUnderstander(llm=llm, prompts_dir=PROMPTS_DIR)
        relevant_files = understander.select_relevant_files(index, issue, max_files=req.max_files)

        # Step 3: LLM Codebase Understanding
        understanding = understander.understand(index, relevant_files, issue)

        # Step 4: Generate minimal patch
        fixer = BugFixer(llm=llm, prompts_dir=PROMPTS_DIR)
        diff = fixer.generate_patch(index, relevant_files, issue, understanding)

        if not diff:
            return {
                "success": False,
                "message": "LLM was unable to generate a valid unified diff.",
                "issue": issue,
                "understanding": understanding,
                "diff": None,
                "changed_files": [],
                "test_before": _format_test_result(before_test),
                "test_after": None,
                "rolled_back": False,
                "patch_applied": False,
            }

        # Step 5: Apply patch safely (unless dry-run)
        applier = PatchApplier(repo_path)
        changed_files = applier.list_changed_files(diff)
        patch_success = False
        patch_message = "Dry run mode: patch not applied."
        after_test: Optional[TestResult] = None
        rolled_back = False

        if not req.dry_run:
            patch_success, patch_message = applier.apply(diff)

            # Step 6: Post-patch test verification
            if patch_success and req.run_tests:
                runner_after = TestRunner(repo_path)
                after_test = runner_after.run()

                # Step 7: Regression check & auto-rollback
                if before_test and after_test:
                    new_failures = after_test.failed > before_test.failed
                    new_errors = after_test.errors > before_test.errors
                    if (new_failures or new_errors) and not after_test.all_passed:
                        applier.rollback()
                        rolled_back = True
                        patch_success = False
                        patch_message = f"Rolled back: Tests regressed ({after_test.failed} failed vs {before_test.failed} before)."

        # Parse structured explanation
        what_was_wrong = "Issue detected in target logic or boundary checking."
        why_it_was_wrong = "Logic violated expected specification or test assertions."
        how_it_was_fixed = "Applied surgical unified diff modifying only the necessary lines."

        if "Root Cause" in understanding:
            parts = understanding.split("###")
            for p in parts:
                if "Root Cause" in p:
                    what_was_wrong = p.replace("Root Cause", "").strip()
                elif "Fix Strategy" in p:
                    how_it_was_fixed = p.replace("Fix Strategy", "").strip()
                elif "Risks" in p:
                    why_it_was_wrong = p.replace("Risks", "").strip()

        return {
            "success": patch_success or req.dry_run,
            "message": patch_message,
            "issue": issue,
            "understanding": understanding,
            "what_was_wrong": what_was_wrong,
            "why_it_was_wrong": why_it_was_wrong,
            "how_it_was_fixed": how_it_was_fixed,
            "diff": diff,
            "changed_files": changed_files,
            "test_before": _format_test_result(before_test),
            "test_after": _format_test_result(after_test),
            "rolled_back": rolled_back,
            "patch_applied": patch_success,
            "provider": getattr(llm, "provider", "unknown"),
        }

    except Exception as exc:
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(exc))
    finally:
        if reader:
            reader.cleanup()
        if temp_repo_path and temp_repo_path.exists():
            shutil.rmtree(temp_repo_path, ignore_errors=True)


@app.post("/api/debug-files")
def debug_files(req: DebugCodeRequest):
    """
    Debug single or multi-file code snippet or uploaded file.
    Does NOT rewrite the entire file; produces minimal unified diff.
    """
    llm = _get_active_llm(req.provider, req.api_key)
    debugger = FileDebugger(llm=llm)

    result = debugger.debug_file(
        filename=req.filename or "code.py",
        content=req.code,
        issue_description=req.issue_description or "",
        error_log=req.error_log or "",
    )
    return result


@app.post("/api/upload-and-debug")
async def upload_and_debug(
    file: UploadFile = File(...),
    issue_description: str = Form(""),
    error_log: str = Form(""),
    provider: Optional[str] = Form(None),
):
    """Handle direct file upload (drag and drop) from UI."""
    content_bytes = await file.read()
    content_str = content_bytes.decode("utf-8", errors="replace")

    llm = _get_active_llm(provider)
    debugger = FileDebugger(llm=llm)

    result = debugger.debug_file(
        filename=file.filename or "uploaded_file.py",
        content=content_str,
        issue_description=issue_description,
        error_log=error_log,
    )
    return result


@app.post("/api/run-benchmark")
def run_benchmark(provider: Optional[str] = None):
    """
    Runs the 'What to build first' Hackathon benchmark demonstration:
    - Pre-test fails (2 failing tests)
    - Agent applies surgical minimal patch (no rewrite)
    - Post-test passes 100%
    """
    req = FixRepoRequest(
        repo="demo",
        issue="Fix pagination calculation: total_pages truncates remainder and out-of-bounds raises IndexError",
        provider=provider or RUN_CONFIG["provider"],
        run_tests=True,
        dry_run=False,
    )
    return fix_repository(req)


# -----------------------------------------------------------------------------
# Static Frontend Serving
# -----------------------------------------------------------------------------

if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

    @app.get("/")
    def serve_index():
        return FileResponse(str(STATIC_DIR / "index.html"))
